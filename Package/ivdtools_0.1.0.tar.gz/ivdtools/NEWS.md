# ivdtools 0.1.0

* Initial release.
* Added workflows for method comparison, ROC analysis, qualitative agreement,
  precision, reference intervals, stability, quality control, curve fitting,
  outlier and normality assessment, and sample-size calculations.
* Added a comprehensive statistical verification suite covering the exported
  API, S3 dispatch, independent formulas, reference implementations, boundary
  inputs, and deterministic property checks.
* Corrected trapezoidal ROC AUC integration when multiple curve points share a
  false-positive rate.
* Added early validation for missing design variables in precision formulas.
