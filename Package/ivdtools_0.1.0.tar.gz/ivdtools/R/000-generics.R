#' Describe an analysis object
#'
#' @param x An S3 analysis object.
#' @param ... Additional arguments passed to a method.
#' @return The value returned by the dispatched method.
#' @export
describe <- function(x, ...) UseMethod("describe")

#' Detect outliers in an analysis object
#'
#' @inheritParams describe
#' @export
outlier <- function(x, ...) UseMethod("outlier")

#' @rdname describe
#' @export
correlation <- function(x, ...) UseMethod("correlation")

#' @rdname describe
#' @export
regression <- function(x, ...) UseMethod("regression")

#' @rdname describe
#' @export
bias <- function(x, ...) UseMethod("bias")

#' @rdname describe
#' @export
bland_altman <- function(x, ...) UseMethod("bland_altman")

#' @param object An S3 analysis object.
#' @rdname describe
#' @export
profile <- function(object, ...) UseMethod("profile")

#' @rdname describe
#' @export
normal <- function(x, ...) UseMethod("normal")

#' @rdname describe
#' @export
ci <- function(x, ...) UseMethod("ci")

#' @rdname describe
#' @export
variance <- function(x, ...) UseMethod("variance")

#' @rdname describe
#' @export
vc <- function(x, ...) UseMethod("vc")

#' @param object An S3 analysis object.
#' @rdname describe
#' @export
diagnostics <- function(object, ...) UseMethod("diagnostics")

#' @rdname describe
#' @export
kappa <- function(x, ...) UseMethod("kappa")

#' @rdname describe
#' @export
mcnemar <- function(x, ...) UseMethod("mcnemar")

#' @rdname describe
#' @export
cutoff <- function(x, ...) UseMethod("cutoff")

#' @rdname describe
#' @export
mlr <- function(x, ...) UseMethod("mlr")

#' @rdname describe
#' @export
auc <- function(x, ...) UseMethod("auc")
