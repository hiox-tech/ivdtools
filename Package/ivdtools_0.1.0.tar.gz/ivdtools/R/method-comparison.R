#' Method Comparison Regression (MCR) Analysis
#'
#' Description: Build mcr class objects, descriptive statistics, correlation/regression/Bland-Altman analysis,
#' outlier detection, bias analysis, and visualization.
#'
#' @importFrom stats cor.test lm coef vcov residuals qt qnorm sd
#'   median quantile
#' @importFrom utils capture.output
#' @importFrom ggplot2 ggplot aes geom_point geom_abline geom_line
#'   geom_hline geom_ribbon labs theme_bw coord_fixed
#'   coord_equal scale_linetype_manual element_text margin
#'   annotate
#' @noRd
NULL

# Zero-safe divisor (preserves sign, avoids division by zero)
.safe_div <- function(x) {
  ifelse(abs(x) < .Machine$double.eps, .Machine$double.eps, x)
}

#' mcr constructor
#'
#' Create a method comparison regression (mcr) object containing sample IDs, test method, and reference method data.
#'
#' @param data  Data frame with id, candidate, reference columns
#' @param id    ID variable name (character), used to identify samples
#' @param candidate Test method variable name (character, method under evaluation)
#' @param reference  Reference method variable name (character, standard method)
#' @param weights Optional column name (character) in data containing non-negative finite
#'   numeric weights for weighted regression. Default NULL (no weighting).
#'
#' @return Returns an S3 "mcr" object containing:
#'   \item{call}{Original function call}
#'   \item{data}{Complete data frame}
#'   \item{id / id_name}{ID vector and column name}
#'   \item{candidate / reference}{Test/reference method numeric vectors (complete pairs only)}
#'   \item{candidate_name / reference_name}{Method column names}
#'   \item{n}{Number of complete pairs}
#'   \item{complete_idx}{Row indices of complete pairs in the original data}
#'   and analysis result storage slots: $correlation, $regression, $outlier, $bland_altman
#'
#' @examples
#'   df <- data.frame(sid = 1:30,
#'                    test = rnorm(30, 50, 10),
#'                    ref  = rnorm(30, 50, 10))
#'   obj <- mcr(df, "sid", "test", "ref")
#' @export
mcr <- function(data, id, candidate, reference, weights = NULL) {

  # Input validation
  if (!is.data.frame(data))
    stop("'data' must be a data frame.")
  if (!is.character(id) || length(id) != 1L || !id %in% names(data))
    stop("'id' must be a single column name in 'data'.")
  if (!is.character(candidate) || length(candidate) != 1L || !candidate %in% names(data))
    stop("'candidate' must be a single column name in 'data'.")
  if (!is.character(reference) || length(reference) != 1L || !reference %in% names(data))
    stop("'reference' must be a single column name in 'data'.")

  # Extract data
  id_vec  <- data[[id]]
  cand    <- data[[candidate]]
  ref     <- data[[reference]]

  if (!is.numeric(cand))
    stop("'candidate' column must be numeric.")
  if (!is.numeric(ref))
    stop("'reference' column must be numeric.")

  # Complete-pair analysis
  ok <- is.finite(cand) & is.finite(ref)
  n  <- sum(ok)
  n_total <- length(cand)
  n_miss  <- n_total - n

  if (n < 3L)
    stop("Need at least 3 complete pairs for method comparison, got ", n, ".")

  # Weights column validation
  if (!is.null(weights)) {
    if (!is.character(weights) || length(weights) != 1L || !weights %in% names(data))
      stop("'weights' must be a single column name in 'data' or NULL.", call. = FALSE)
    w_col <- data[[weights]]
    if (!is.numeric(w_col))
      stop("'weights' column must be numeric.", call. = FALSE)
    weights_vec <- w_col[ok]
    if (any(!is.finite(weights_vec) | weights_vec < 0))
      stop("'weights' column must contain non-negative finite values.", call. = FALSE)
  } else {
    weights_vec <- NULL
  }

  # Construct object
  # Print slot: data overview
  id_vec_all <- data[[id]]
  dups <- duplicated(id_vec_all) | duplicated(id_vec_all, fromLast = TRUE)
  n_dup <- sum(dups)
  dup_ids <- if (n_dup > 0) which(dups) else integer(0)

  miss_cand <- !is.finite(cand)
  miss_ref  <- !is.finite(ref)

  print_slot <- list(
    data_class   = class(data)[1L],
    n            = n,
    n_total      = n_total,
    n_miss       = n_miss,
    n_dup        = n_dup,
    var_names    = list(id = id, candidate = candidate, reference = reference),
    dup_ids      = dup_ids,
    miss_ids     = list(
      candidate  = which(miss_cand & !miss_ref),
      reference  = which(miss_ref & !miss_cand),
      both       = which(miss_cand & miss_ref)
    ),
    weights_name = weights
  )

  out <- list(
    call            = match.call(),
    data            = data,
    id              = id_vec[ok],
    id_name         = id,
    candidate       = cand[ok],
    reference       = ref[ok],
    candidate_name  = candidate,
    reference_name  = reference,
    n               = n,
    complete_idx    = which(ok),
    print           = print_slot,
    weights_name    = weights,
    weights         = weights_vec,
    describe        = NULL,
    correlation     = NULL,
    regression      = NULL,
    outlier         = NULL,
    bland_altman    = NULL,
    bias            = NULL
  )
  class(out) <- "mcr"

  invisible(out)
}


#' S3 print method
#'
#' Print data overview and analysis slot status based on \code{$print} slot.
#'
#' @param x \code{mcr} object
#' @param ... Additional arguments
#'
#' @return Invisible \code{mcr} object
#'
#' @export
#'
#' @examples
#'   df <- data.frame(sid = 1:30,
#'                    test = rnorm(30, 50, 10),
#'                    ref  = rnorm(30, 50, 10))
#'   obj <- mcr(df, "sid", "test", "ref")
#'   print(obj)
print.mcr <- function(x, ...) {

  if (!inherits(x, "mcr"))
    stop("Input must be an 'mcr' object.")

  p <- x$print %||% list(
    data_class = class(x$data)[1L],
    n          = x$n,
    n_total    = nrow(x$data),
    n_miss     = nrow(x$data) - x$n,
    n_dup      = 0L,
    var_names  = list(id = x$id_name, candidate = x$candidate_name,
                      reference = x$reference_name),
    dup_ids    = integer(0),
    miss_ids   = list(candidate = integer(0), reference = integer(0), both = integer(0))
  )

  cat("\nMethod Comparison\n")
  cat(sprintf("  Data class:        %s\n", p$data_class))
  cat(sprintf("  Total rows:        %d\n", p$n_total))
  cat(sprintf("  Complete pairs:    %d\n", p$n))
  if (p$n_miss > 0)
    cat(sprintf("  Missing/excluded:  %d\n", p$n_miss))
  cat(sprintf("  ID variable:       %s\n", p$var_names$id))
  cat(sprintf("  Test method (X):   %s\n", p$var_names$candidate))
  cat(sprintf("  Reference (Y):     %s\n", p$var_names$reference))
  if (p$n_dup > 0)
    cat(sprintf("  Duplicate IDs:     %d (rows: %s)\n",
                p$n_dup, paste(p$dup_ids, collapse = ", ")))
  else
    cat("  Duplicate IDs:     none\n")

  if (!is.null(p$weights_name))
    cat(sprintf("  Weights column:   %s\n", p$weights_name))

  # Missing detail
  if (p$n_miss > 0) {
    cat("  Missing value detail:\n")
    if (length(p$miss_ids$candidate))
      cat(sprintf("    %s: %d row(s): %s\n",
                  p$var_names$candidate, length(p$miss_ids$candidate),
                  paste(p$miss_ids$candidate, collapse = ", ")))
    if (length(p$miss_ids$reference))
      cat(sprintf("    %s: %d row(s): %s\n",
                  p$var_names$reference, length(p$miss_ids$reference),
                  paste(p$miss_ids$reference, collapse = ", ")))
    if (length(p$miss_ids$both))
      cat(sprintf("    both: %d row(s): %s\n",
                  length(p$miss_ids$both),
                  paste(p$miss_ids$both, collapse = ", ")))
  }

  # Analysis slot status
  cat("\nAnalysis slots:\n")
  slots <- list(
    describe    = "Describe",
    correlation = "Correlation",
    regression  = "Regression",
    outlier     = "Outlier",
    bland_altman = "Bland-Altman",
    bias        = "Bias"
  )
  for (nm in names(slots)) {
    val <- x[[nm]]
    if (!is.null(val)) {
      extra <- ""
      if (nm == "correlation") extra <- sprintf(" (%s)", val$method)
      else if (nm == "regression") extra <- sprintf(" (%s)", val$method)
      else if (nm == "outlier") extra <- sprintf(" (%s)", val$method)
      else if (nm == "bland_altman") extra <- sprintf(" (%s)", val$type)
      cat(sprintf("    [x] %s%s\n", slots[[nm]], extra))
    } else {
      cat(sprintf("    [ ] %s\n", slots[[nm]]))
    }
  }

  invisible(x)
}


#' S3 summary method
#'
#' Summarize key information from all executed analyses in the \code{mcr} object
#' (descriptive statistics, correlation analysis, regression analysis,
#' outlier detection, Bland-Altman analysis, and bias analysis).
#'
#' @param object \code{mcr} object
#' @param ... Additional arguments
#'
#' @return Invisible \code{mcr} object
#'
#' @examples
#'   df <- data.frame(sid = 1:30,
#'                    test = rnorm(30, 50, 10),
#'                    ref  = rnorm(30, 50, 10))
#'   obj <- mcr(df, "sid", "test", "ref")
#'   summary(obj)
#'   obj <- correlation(obj)
#'   obj <- regression(obj, method = "ols")
#'   obj <- bland_altman(obj)
#'   summary(obj)
#' @export
summary.mcr <- function(object, ...) {

  if (!inherits(object, "mcr"))
    stop("Input must be an 'mcr' object.")

  p <- object$print %||% list(
    data_class = class(object$data)[1L],
    n          = object$n,
    n_total    = nrow(object$data),
    n_miss     = nrow(object$data) - object$n,
    n_dup      = 0L,
    var_names  = list(id = object$id_name, candidate = object$candidate_name,
                      reference = object$reference_name)
  )

  cat("\nMethod Comparison Regression (mcr)\n")
  cat("-----------------------------------------------------\n")
  print.mcr(object)


  # Detail: Describe
  if (!is.null(object$describe)) print(object$describe)

  # Detail: Correlation
  if (!is.null(object$correlation)) print(object$correlation)

  # Detail: Regression
  if (!is.null(object$regression)) print(object$regression)

  # Detail: Outlier
  if (!is.null(object$outlier)) print(object$outlier)

  # Detail: Bland-Altman
  if (!is.null(object$bland_altman)) print(object$bland_altman)

  # Detail: Bias
  if (!is.null(object$bias)) print(object$bias)

  invisible(object)
}


#' Print method for describe results
#' @param x mcr_describe object
#' @param digits Number of decimal places, default 4
#' @param ... additional arguments
#' @export
print.mcr_describe <- function(x, digits = NULL, ...) {
  d <- x
  if (is.null(digits)) digits <- 4L

  # Method comparison table + other numeric columns
  cat("\nDescriptive Statistics\n")

  # Three rows for method comparison
  tbl_rows <- list(
    list(name = sprintf("  %s (X)", d$candidate_name), vals = d$candidate_values),
    list(name = sprintf("  %s (Y)", d$reference_name), vals = d$reference_values),
    list(name = "  Diff (X-Y)",              vals = d$diff_values)
  )

  # Add other numeric columns to the main table
  cat_cols <- list()
  for (col in names(d$columns)) {
    ci <- d$columns[[col]]
    if (ci$type == "numeric") {
      tbl_rows[[length(tbl_rows) + 1]] <- list(name = sprintf("  %s", col), vals = d$numeric_extra[[col]])
    } else if (ci$type == "categorical") {
      cat_cols[[col]] <- ci
    }
  }

  # Table header
  sep75 <- paste(rep("-", 75), collapse = "")
  cat(sprintf("  %-18s %5s %8s %8s %8s %8s %8s %8s %8s  %s\n",
              "Variable", "n", "Mean", "SD", "Min", "Q1", "Median", "Q3", "Max", "NA"))
  cat(" ", sep75, "\n")

  for (m in tbl_rows) {
    v <- m$vals
    n <- length(v)
    n_na <- sum(is.na(v))
    if (n == 0) {
      cat(sprintf("  %-18s %5d %8s %8s %8s %8s %8s %8s %8s  %s\n",
                  m$name, 0L, "-", "-", "-", "-", "-", "-", "-", if (n_na > 0) n_na else ""))
    } else {
      ok <- v[!is.na(v)]
      if (length(ok) == 0) {
        cat(sprintf("  %-18s %5d %8s %8s %8s %8s %8s %8s %8s  %d\n",
                    m$name, n, "-", "-", "-", "-", "-", "-", "-", n_na))
      } else {
        na_str <- if (n_na > 0) sprintf("%d", n_na) else ""
        cat(sprintf("  %-18s %5d %8s %8s %8s %8s %8s %8s %8s  %s\n",
                    m$name, length(ok),
                    .format_num(mean(ok), digits),
                    .format_num(sd(ok),   digits),
                    .format_num(min(ok),  digits),
                    .format_num(quantile(ok, 0.25, names = FALSE), digits),
                    .format_num(median(ok), digits),
                    .format_num(quantile(ok, 0.75, names = FALSE), digits),
                    .format_num(max(ok),  digits),
                    na_str))
      }
    }
  }

  # Categorical table
  for (col in names(cat_cols)) {
    ci <- cat_cols[[col]]
    na_str <- if (ci$n_na > 0)
      sprintf(" (%d NA, %.1f%%)", ci$n_na, ci$pct_na) else ""

    cat(sprintf("\n  %s%s\n", col, na_str))
    cat(sprintf("  %-20s %5s  %7s\n", "Level", "Count", "Percent"))
    cat("  ", paste(rep("-", 38), collapse = ""), "\n")
    for (r in seq_len(nrow(ci$table))) {
      lv <- as.character(ci$table$Level[r])
      if (is.na(lv)) lv <- "<NA>"
      cat(sprintf("  %-20s %5d  %6.1f%%\n",
                  lv, ci$table$Freq[r], ci$table$Pct[r]))
    }
  }

  invisible(x)
}

#' Print method for correlation results
#' @param x mcr_correlation object
#' @param ... additional arguments
#' @export
print.mcr_correlation <- function(x, ...) {
  cl_pct <- if (!is.null(x$conf.int))
    sprintf(", %.0f%% CI [%.4f, %.4f]",
            attr(x$conf.int, "conf.level") * 100,
            x$conf.int[1L], x$conf.int[2L]) else ""
  cat("\nCorrelation\n")
  cat(sprintf("  Method: %s\n", x$method))
  cat(sprintf("  r = %.4f%s\n", x$estimate, cl_pct))
  cat(sprintf("  p-value: %s\n", format.pval(x$p.value, digits = 4)))
  cat(sprintf("  n = %d\n", x$n))
  invisible(x)
}

#' Print method for regression results
#' @param x mcr_regression object
#' @param ... additional arguments
#' @export
print.mcr_regression <- function(x, ...) {
  cat("\nRegression\n")
  cat(sprintf("  Method: %s\n", x$method))
  if (!is.null(x$weights_spec))
    cat(sprintf("  Weights: %s\n", x$weights_spec))
  cat(sprintf("  Intercept = %s  (SE = %s)\n",
              .format_num(x$intercept), .format_num(x$intercept_se)))
  cat(sprintf("  Slope     = %s  (SE = %s)\n",
              .format_num(x$slope), .format_num(x$slope_se)))
  cl_pct <- x$conf.level * 100
  cat(sprintf("  Intercept %.0f%% CI: [%s, %s]\n", cl_pct,
              .format_num(x$intercept_ci[1L]), .format_num(x$intercept_ci[2L])))
  cat(sprintf("  Slope     %.0f%% CI: [%s, %s]\n", cl_pct,
              .format_num(x$slope_ci[1L]), .format_num(x$slope_ci[2L])))
  if (!is.na(x$slope_se) && is.finite(x$slope_se)) {
    t_slope1 <- (x$slope - 1) / x$slope_se
    p_slope1 <- 2 * pt(-abs(t_slope1), df = x$n - 2)
    ci_contains_1 <- x$slope_ci[1L] <= 1 && x$slope_ci[2L] >= 1
    cat(sprintf("    H0: slope = 1 -> t = %.4f, p = %s\n",
                t_slope1, format.pval(p_slope1, digits = 4)))
    if (p_slope1 >= 1 - x$conf.level) {
      cat("    slope not significantly different from 1",
          if (ci_contains_1) " (CI contains 1)" else "", "\n", sep = "")
    } else {
      cat("    slope significantly different from 1",
          if (!ci_contains_1) " (CI excludes 1)" else "", "\n", sep = "")
    }
  }
  if (!is.null(x$r_squared))
    cat(sprintf("  R-squared = %.4f\n", x$r_squared))
  cat(sprintf("  Sigma     = %s\n", .format_num(x$sigma)))
  cat(sprintf("  n = %d\n", x$n))
  invisible(x)
}

#' Print method for outlier results
#' @param x mcr_outlier object
#' @param ... additional arguments
#' @export
print.mcr_outlier <- function(x, ...) {
  cat("\nOutlier\n")
  cat(sprintf("  Method: %s\n", x$method))
  cat(sprintf("  Data:   %s\n", x$data_label))
  cat(sprintf("  Alpha:  %.2f", x$alpha))
  if (x$method == "iqr")
    cat(sprintf("  (coef = %.1f)", x$coef))
  cat("\n\n")
  if (x$n_out == 0L) {
    cat("  No outliers detected.\n")
  } else {
    cat(sprintf("  %d outlier(s) found:\n", x$n_out))
    cat(sprintf("  %-12s  %10s  %10s  %s\n", "Row", "Value", "Statistic", "Critical"))
    cat("  ", paste(rep("-", 50), collapse = ""), "\n")
    for (i in seq_len(x$n_out)) {
      s <- if (length(x$statistic) >= i) x$statistic[i] else x$statistic
      c <- if (length(x$critical) >= i) x$critical[i] else x$critical
      cat(sprintf("  %-12d  %10.4f  %10.4f  %.4f\n",
                  x$indices[i], x$values[i], s, c))
    }
  }

  invisible(x)
}

#' Print method for Bland-Altman results
#' @param x mcr_bland_altman object
#' @param ... additional arguments
#' @export
print.mcr_bland_altman <- function(x, ...) {
  agree_pct <- x$agree.level * 100
  conf_pct  <- x$conf.level * 100
  cat("\nBland-Altman\n")
  cat(sprintf("  Type:        %s\n", x$type))
  cat(sprintf("  Y-axis:      %s\n", x$y_label))
  cat(sprintf("  X-axis:      %s\n", x$x_label))
  cat(sprintf("  n = %d\n\n", x$n))
  cat(sprintf("  Mean diff:       %s\n", .format_num(x$mean_diff)))
  cat(sprintf("  SD diff:         %s\n", .format_num(x$sd_diff)))
  cat(sprintf("  %.0f%% LoA: [%s, %s]\n", agree_pct,
              .format_num(x$loa[1L]), .format_num(x$loa[2L])))
  cat(sprintf("\n  %.0f%% CI for LoA:\n", conf_pct))
  cat(sprintf("    Lower LoA: [%s, %s]\n",
              .format_num(x$loa_ci$lower[1L]), .format_num(x$loa_ci$lower[2L])))
  cat(sprintf("    Upper LoA: [%s, %s]\n",
              .format_num(x$loa_ci$upper[1L]), .format_num(x$loa_ci$upper[2L])))
  invisible(x)
}

#' Print method for bias results
#' @param x mcr_bias object
#' @param ... additional arguments
#' @export
print.mcr_bias <- function(x, ...) {
  cat("\nBias\n")
  cat(sprintf("  Method: %s\n", attr(x, "method") %||% "N/A"))
  interval <- attr(x, "interval") %||% ""
  level    <- attr(x, "level") %||% 0.95
  if (nchar(interval) > 0)
    cat(sprintf("  Interval: %s (%.0f%%)\n", interval, level * 100))
  else
    cat("  Interval: point estimate only\n")
  cat(sprintf("  MDL points: %d\n", nrow(x)))
  cat(sprintf("  Bias range: [%s, %s]\n",
              .format_num(min(x$bias)), .format_num(max(x$bias))))
  cat("\n")
  txt <- capture.output(print.data.frame(x, row.names = FALSE))
  cat(txt[1L], "\n")
  cat(paste(rep("-", nchar(txt[1L])), collapse = ""), "\n")
  cat(paste(txt[-1L], collapse = "\n"), "\n")
  invisible(x)
}
#'
#' Compute descriptive statistics and store results
#'
#' Computes data overview (rows/columns/ID duplicates), per-column summaries,
#' and a side-by-side comparison table of candidate, reference, and Diff.
#' Results are stored in \code{x$describe} (class \code{mcr_describe}) and
#' displayed via \code{print.mcr_describe()} (e.g., when calling \code{summary()}).
#'
#' @param x       mcr object
#' @param cols    Column name vector to analyze; by default, analyzes all columns except
#'                id, candidate, and reference. Supports exclusion with \code{-} prefix,
#'                e.g., cols = -c("age", "sex").
#' @param digits  Number of decimal places, default 4
#' @param ...     Additional arguments
#'
#' @return Updated \code{mcr} object (invisible), results stored in \code{x$describe}
#'
#' @examples
#'   obj <- mcr(ivd_mcr_example, "sid", "test", "ref")
#'   describe(obj)
#' @export
describe.mcr <- function(x, cols = NULL, digits = 4L, ...) {

  if (!inherits(x, "mcr"))
    stop("Input must be an 'mcr' object.")

  data <- x$data
  n_col <- ncol(data)
  all_names <- names(data)

  # Determine which columns to analyze
  # By default, exclude id, candidate, reference columns
  exclude_default <- c(x$id_name, x$candidate_name, x$reference_name)

  cols_expr <- substitute(cols)
  negated <- FALSE
  if (is.call(cols_expr) &&
      length(cols_expr) == 2 && identical(cols_expr[[1]], as.name("-"))) {
    negated <- TRUE
    cols <- eval(cols_expr[[2]], parent.frame())
  }

  if (is.null(cols)) {
    cols <- setdiff(all_names, exclude_default)
  } else if (negated) {
    cols <- setdiff(all_names, cols)
  } else {
    include <- grep("^-", cols, value = TRUE, invert = TRUE)
    exclude <- grep("^-", cols, value = TRUE)
    exclude <- sub("^-", "", exclude)
    if (length(include) > 0) {
      bad <- setdiff(include, all_names)
      if (length(bad))
        stop("Column(s) not found: ", paste(bad, collapse = ", "))
      cols <- include
    } else {
      cols <- setdiff(all_names, exclude_default)
    }
    if (length(exclude) > 0) {
      bad <- setdiff(exclude, all_names)
      if (length(bad))
        stop("Column(s) to exclude not found: ", paste(bad, collapse = ", "))
      cols <- setdiff(cols, exclude)
    }
  }
  # Always exclude id
  cols <- setdiff(cols, x$id_name)

  # ID duplicate check (based on complete pairs)
  id_dup <- NULL
  id_vec <- x$id
  dups <- duplicated(id_vec) | duplicated(id_vec, fromLast = TRUE)
  n_dup <- sum(dups)
  n_unique <- length(unique(id_vec))
  id_dup <- list(n_dup = n_dup, n_unique = n_unique)

  # Per-column summary (based on original data frame)
  columns <- list()

  for (col in cols) {
    vec     <- data[[col]]
    n_total <- length(vec)
    n_na    <- sum(is.na(vec))
    pct_na  <- round(n_na / n_total * 100, 1)

    if (is.factor(vec) || is.character(vec)) {
      tbl   <- table(vec, useNA = "ifany")
      n_ok  <- sum(!is.na(vec))
      freqs <- as.data.frame(tbl, responseName = "Freq")
      names(freqs)[1] <- "Level"
      freqs$Pct <- round(freqs$Freq / n_ok * 100, 1)
      na_row <- which(is.na(freqs$Level))
      if (length(na_row))
        freqs$Pct[na_row] <- round(freqs$Freq[na_row] / n_total * 100, 1)

      columns[[col]] <- list(
        type     = "categorical",
        n_na     = n_na,
        pct_na   = pct_na,
        n_levels = nrow(freqs),
        table    = freqs
      )

    } else if (is.numeric(vec)) {
      ok  <- vec[!is.na(vec)]
      if (length(ok) == 0) {
        columns[[col]] <- list(
          type = "numeric", n_na = n_na, pct_na = pct_na,
          n = 0L, mean = NA_real_, sd = NA_real_,
          min = NA_real_, q25 = NA_real_, median = NA_real_,
          q75 = NA_real_, max = NA_real_
        )
      } else {
        columns[[col]] <- list(
          type   = "numeric",
          n_na   = n_na,
          pct_na = pct_na,
          n      = length(ok),
          mean   = mean(ok),
          sd     = sd(ok),
          min    = min(ok),
          q25    = quantile(ok, 0.25, names = FALSE),
          median = median(ok),
          q75    = quantile(ok, 0.75, names = FALSE),
          max    = max(ok)
        )
      }
    } else {
      columns[[col]] <- list(type = "other", n_na = n_na, pct_na = pct_na)
    }
  }

  # Gather complete-pair values for numeric extra columns (for print method)
  numeric_table_cols <- list()
  for (col in names(columns)) {
    ci <- columns[[col]]
    if (ci$type == "numeric") {
      numeric_table_cols[[col]] <- data[[col]][x$complete_idx]
    }
  }

  result <- structure(list(
    n_complete       = x$n,
    n_total          = nrow(data),
    n_col            = n_col,
    id_dup           = id_dup,
    columns          = columns,
    id_name          = x$id_name,
    candidate_name   = x$candidate_name,
    reference_name   = x$reference_name,
    candidate_values = x$candidate,
    reference_values = x$reference,
    diff_values      = x$candidate - x$reference,
    numeric_extra    = numeric_table_cols
  ), class = "mcr_describe")
  x$describe <- result
  print(result)
  invisible(x)
}


#' Correlation analysis (S3 method)
#'
#' Perform correlation analysis between the test method (X) and reference method (Y),
#' supporting Pearson, Spearman, and Kendall methods.
#'
#' @param x       mcr object
#' @param method  Correlation method: "pearson" (default), "spearman", or "kendall"
#' @param ...     Additional arguments passed to cor.test
#'
#' @return Updated mcr object (invisible), results stored in $correlation
#'
#' @examples
#'   obj <- mcr(ivd_mcr_example, "sid", "test", "ref")
#'   correlation(obj)
#'   correlation(obj, method = "spearman")
#' @export
correlation.mcr <- function(x, method = c("pearson", "spearman", "kendall"), ...) {

  if (!inherits(x, "mcr"))
    stop("Input must be an 'mcr' object.")

  method <- match.arg(method)

  # Computation
  ct <- cor.test(x$candidate, x$reference, method = method, ...)

  # Storage
  result <- structure(list(
    method    = method,
    estimate  = as.numeric(ct$estimate),
    statistic = as.numeric(ct$statistic),
    parameter = as.numeric(ct$parameter),
    p.value   = ct$p.value,
    conf.int  = ct$conf.int,
    n         = x$n
  ), class = "mcr_correlation")
  x$correlation <- result

  print(result)
  invisible(x)
}


# Internal function: Deming regression (closed-form, Linnet 1993)
.deming_fit <- function(x, y, lambda = 1, conf.level = 0.95) {

  n <- length(x)
  if (!is.numeric(conf.level) || length(conf.level) != 1L ||
      is.na(conf.level) || conf.level <= 0 || conf.level >= 1)
    stop("'conf.level' must be a single number in (0, 1).", call. = FALSE)
  if (!is.numeric(lambda) || length(lambda) != 1L ||
      is.na(lambda) || lambda <= 0)
    stop("'lambda' must be a single positive number.", call. = FALSE)
  mx <- mean(x); my <- mean(y)

  s_xx <- sum((x - mx)^2)
  s_yy <- sum((y - my)^2)
  s_xy <- sum((x - mx) * (y - my))

  if (s_xy == 0)
    stop("Zero covariance between x and y; cannot fit Deming regression.")

  # Deming slope & intercept (Linnet 1993, eq. 5)
  U <- s_yy - lambda * s_xx
  slope <- (U + sqrt(U^2 + 4 * lambda * s_xy^2)) / (2 * s_xy)
  intercept <- my - slope * mx

  # Jackknife SE
  jack_slope <- numeric(n)
  jack_int   <- numeric(n)
  for (i in seq_len(n)) {
    xi <- x[-i]; yi <- y[-i]
    mi_x <- mean(xi); mi_y <- mean(yi)
    sxx_i <- sum((xi - mi_x)^2)
    syy_i <- sum((yi - mi_y)^2)
    sxy_i <- sum((xi - mi_x) * (yi - mi_y))
    if (sxy_i == 0) next
    U_i <- syy_i - lambda * sxx_i
    jack_slope[i] <- (U_i + sqrt(U_i^2 + 4 * lambda * sxy_i^2)) / (2 * sxy_i)
    jack_int[i]   <- mi_y - jack_slope[i] * mi_x
  }
  slope_se <- sqrt((n - 1) / n * sum((jack_slope - mean(jack_slope, na.rm = TRUE))^2, na.rm = TRUE))
  int_se   <- sqrt((n - 1) / n * sum((jack_int   - mean(jack_int,   na.rm = TRUE))^2, na.rm = TRUE))
  cov_xy   <- (n - 1) / n * sum((jack_slope - mean(jack_slope, na.rm = TRUE)) *
                                 (jack_int   - mean(jack_int,   na.rm = TRUE)),
                                 na.rm = TRUE)

  # Residuals and sigma
  predicted <- intercept + slope * x
  residuals <- y - predicted
  sigma <- sqrt(sum(residuals^2) / (n - 2))

  t_val <- qt(1 - (1 - conf.level) / 2, n - 2)

  list(
    method        = "Deming",
    intercept     = intercept,
    slope         = slope,
    intercept_se  = int_se,
    slope_se      = slope_se,
    cov_xy        = cov_xy,
    intercept_ci  = c(intercept - t_val * int_se, intercept + t_val * int_se),
    slope_ci      = c(slope - t_val * slope_se, slope + t_val * slope_se),
    sigma         = sigma,
    residuals     = residuals,
    lambda        = lambda,
    n             = n,
    conf.level    = conf.level
  )
}


# Internal function: Weighted Deming regression
.wdeming_fit <- function(x, y, lambda = 1, weights = NULL, conf.level = 0.95) {

  n <- length(x)
  if (is.null(weights))
    weights <- rep(1, n)

  if (!is.numeric(weights) || length(weights) != n)
    stop("'weights' must be a numeric vector of length ", n,
         " (number of complete pairs), got ", length(weights), ".", call. = FALSE)
  if (any(!is.finite(weights) | weights < 0))
    stop("'weights' must be non-negative and finite.", call. = FALSE)
  if (!is.numeric(conf.level) || length(conf.level) != 1L ||
      is.na(conf.level) || conf.level <= 0 || conf.level >= 1)
    stop("'conf.level' must be a single number in (0, 1).", call. = FALSE)
  if (!is.numeric(lambda) || length(lambda) != 1L ||
      is.na(lambda) || lambda <= 0)
    stop("'lambda' must be a single positive number.", call. = FALSE)

  w <- weights / sum(weights) * n  # Normalize
  mx <- sum(w * x) / n
  my <- sum(w * y) / n

  s_xx <- sum(w * (x - mx)^2)
  s_yy <- sum(w * (y - my)^2)
  s_xy <- sum(w * (x - mx) * (y - my))

  if (s_xy == 0)
    stop("Zero weighted covariance between x and y.")

  U <- s_yy - lambda * s_xx
  slope <- (U + sqrt(U^2 + 4 * lambda * s_xy^2)) / (2 * s_xy)
  intercept <- my - slope * mx

  # Jackknife SE
  jack_slope <- numeric(n)
  jack_int   <- numeric(n)
  for (i in seq_len(n)) {
    xi <- x[-i]; yi <- y[-i]; wi <- weights[-i]
    wi <- wi / sum(wi) * (n - 1)
    mi_x <- sum(wi * xi) / (n - 1)
    mi_y <- sum(wi * yi) / (n - 1)
    sxx_i <- sum(wi * (xi - mi_x)^2)
    syy_i <- sum(wi * (yi - mi_y)^2)
    sxy_i <- sum(wi * (xi - mi_x) * (yi - mi_y))
    if (sxy_i == 0) next
    U_i <- syy_i - lambda * sxx_i
    jack_slope[i] <- (U_i + sqrt(U_i^2 + 4 * lambda * sxy_i^2)) / (2 * sxy_i)
    jack_int[i]   <- mi_y - jack_slope[i] * mi_x
  }
  slope_se <- sqrt((n - 1) / n * sum((jack_slope - mean(jack_slope, na.rm = TRUE))^2, na.rm = TRUE))
  int_se   <- sqrt((n - 1) / n * sum((jack_int   - mean(jack_int,   na.rm = TRUE))^2, na.rm = TRUE))
  cov_xy   <- (n - 1) / n * sum((jack_slope - mean(jack_slope, na.rm = TRUE)) *
                                 (jack_int   - mean(jack_int,   na.rm = TRUE)),
                                 na.rm = TRUE)

  predicted <- intercept + slope * x
  residuals <- y - predicted
  sigma <- sqrt(sum(w * residuals^2) / (n - 2))

  t_val <- qt(1 - (1 - conf.level) / 2, n - 2)

  list(
    method        = "Weighted Deming",
    intercept     = intercept,
    slope         = slope,
    intercept_se  = int_se,
    slope_se      = slope_se,
    cov_xy        = cov_xy,
    intercept_ci  = c(intercept - t_val * int_se, intercept + t_val * int_se),
    slope_ci      = c(slope - t_val * slope_se, slope + t_val * slope_se),
    sigma         = sigma,
    residuals     = residuals,
    lambda        = lambda,
    n             = n,
    conf.level    = conf.level
  )
}


# Internal function: Passing-Bablok regression
.pb_fit <- function(x, y, conf.level = 0.95) {

  n <- length(x)
  if (n < 5L)
    stop("Passing-Bablok regression requires at least 5 complete pairs, got ", n, ".")

  # All pairwise slopes
  slopes <- numeric(0)
  for (i in 1:(n - 1)) {
    for (j in (i + 1):n) {
      denom <- x[j] - x[i]
      if (abs(denom) > .Machine$double.eps) {
        s <- (y[j] - y[i]) / denom
        # Exclude slopes exactly equal to -1 (Passing & Bablok theoretical requirement)
        if (abs(s + 1) > .Machine$double.eps)
          slopes <- c(slopes, s)
      }
    }
  }

  m <- length(slopes)
  if (m == 0L)
    stop("No valid pairwise slopes for Passing-Bablok regression.")

  slopes <- sort(slopes)

  # Regression estimates
  slope_est <- median(slopes)
  intercept_est <- median(y - slope_est * x)

  # Slope confidence interval
  z <- qnorm(1 - (1 - conf.level) / 2)
  K <- (n * (n - 1) / 2 - z * sqrt(n * (n - 1) * (2 * n + 5) / 18)) / 2
  K <- max(1, floor(K))
  ci_lower <- slopes[K]
  ci_upper <- slopes[m - K + 1]

  # Intercept confidence interval (based on slope CI bounds)
  int_lower <- median(y - ci_upper * x)
  int_upper <- median(y - ci_lower * x)

  # Residuals (for sigma)
  residuals <- y - (intercept_est + slope_est * x)
  sigma <- sqrt(sum(residuals^2) / (n - 2))

  list(
    method        = "Passing-Bablok",
    intercept     = intercept_est,
    slope         = slope_est,
    intercept_se  = NA_real_,
    slope_se      = NA_real_,
    cov_xy        = NA_real_,
    intercept_ci  = c(int_lower, int_upper),
    slope_ci      = c(ci_lower, ci_upper),
    sigma         = sigma,
    residuals     = residuals,
    lambda        = NA_real_,
    n_slopes      = m,
    n             = n,
    conf.level    = conf.level
  )
}


# Internal function: resolve weights specification to numeric vector
.resolve_weights <- function(x, weights) {
  if (is.null(weights)) return(NULL)

  if (!is.character(weights) || length(weights) != 1L)
    stop("'weights' must be a character string or NULL.", call. = FALSE)

  # Built-in modes
  if (weights %in% c("equal", "1/y", "1/y^2", "1/x", "1/x^2")) {
    w <- switch(weights,
      "equal" = rep(1, x$n),
      "1/y"   = 1 / pmax(abs(x$reference), .Machine$double.eps),
      "1/y^2" = 1 / pmax(x$reference^2, .Machine$double.eps),
      "1/x"   = 1 / pmax(abs(x$candidate), .Machine$double.eps),
      "1/x^2" = 1 / pmax(x$candidate^2, .Machine$double.eps)
    )
    return(w)
  }

  # Column name in data
  if (weights %in% names(x$data)) {
    w <- x$data[[weights]][x$complete_idx]
    if (!is.numeric(w) || any(!is.finite(w)) || any(w < 0))
      stop("'weights' column must contain non-negative finite numeric values.",
           call. = FALSE)
    return(w)
  }

  stop("'weights' must be one of 'equal', '1/y', '1/y^2', '1/x', '1/x^2',\n",
       "  a column name in data, or NULL.", call. = FALSE)
}


#' Regression analysis (S3 method)
#'
#' Perform regression analysis between the test method (X) and reference method (Y).
#' Supports five methods: Ordinary Least Squares (OLS), Weighted Least Squares (WLS),
#' Deming regression, Weighted Deming regression, and Passing-Bablok regression.
#'
#' @param x          mcr object
#' @param method     Regression method: "ols" (default), "wls", "deming", "wdeming", "pb"
#' @param conf.level Confidence level, default 0.95
#' @param lambda     Variance ratio for Deming regression (reference variance
#'   divided by candidate variance), default 1
#' @param weights    Weights specification, default NULL (unweighted).
#'   Character string for built-in modes: "equal", "1/y", "1/y^2", "1/x", "1/x^2",
#'   or a column name in data containing non-negative weights.
#'   For OLS: weights are passed to lm() when provided.
#'   For WLS / Weighted Deming: weights are required (error if NULL).
#'   For Deming / Passing-Bablok: weights are ignored (with a warning).
#' @param ...        Additional arguments passed to lm (OLS/WLS only)
#'
#' @return Updated mcr object (invisible), results stored in $regression
#'
#' @examples
#'   obj <- mcr(ivd_mcr_example, "sid", "test", "ref")
#'   regression(obj, method = "ols")
#'   regression(obj, method = "deming")
#'   regression(obj, method = "pb")
#' @export
regression.mcr <- function(x,
                            method = c("ols", "wls", "deming", "wdeming", "pb"),
                            conf.level = 0.95, lambda = 1,
                            weights = NULL, ...) {

  if (!inherits(x, "mcr"))
    stop("Input must be an 'mcr' object.")

  method <- match.arg(method)

  if (x$n < 3L)
    stop("Need at least 3 complete pairs for regression, got ", x$n, ".")

  # Parameter range validation
  if (!is.numeric(conf.level) || length(conf.level) != 1L ||
      is.na(conf.level) || conf.level <= 0 || conf.level >= 1)
    stop("'conf.level' must be a single number in (0, 1).", call. = FALSE)
  if (method %in% c("deming", "wdeming")) {
    if (!is.numeric(lambda) || length(lambda) != 1L ||
        is.na(lambda) || lambda <= 0)
      stop("'lambda' must be a single positive number.", call. = FALSE)
  }

  # Resolve weights
  w <- .resolve_weights(x, weights)

  # Dispatch by method
  if (method == "ols") {
    fit <- if (!is.null(w)) lm(x$reference ~ x$candidate, weights = w, ...)
           else lm(x$reference ~ x$candidate, ...)
    s <- summary(fit)
    coefs <- coef(s)
    t_val <- qt(1 - (1 - conf.level) / 2, df.residual(fit))

    result <- list(
      method       = "OLS",
      intercept    = coefs[1L, 1L],
      slope        = coefs[2L, 1L],
      intercept_se = coefs[1L, 2L],
      slope_se     = coefs[2L, 2L],
      cov_xy       = vcov(fit)[1L, 2L],
      intercept_ci = coefs[1L, 1L] + c(-1, 1) * t_val * coefs[1L, 2L],
      slope_ci     = coefs[2L, 1L] + c(-1, 1) * t_val * coefs[2L, 2L],
      sigma        = s$sigma,
      r_squared    = s$r.squared,
      residuals    = residuals(fit),
      lambda       = NA_real_,
      weights_spec = weights,
      n            = x$n,
      conf.level   = conf.level
    )

  } else if (method == "wls") {
    if (is.null(w))
      stop("'weights' must be provided for WLS. Use method = \"ols\" for unweighted regression.",
           call. = FALSE)
    fit <- lm(x$reference ~ x$candidate, weights = w, ...)
    s <- summary(fit)
    coefs <- coef(s)
    t_val <- qt(1 - (1 - conf.level) / 2, df.residual(fit))

    result <- list(
      method       = "WLS",
      intercept    = coefs[1L, 1L],
      slope        = coefs[2L, 1L],
      intercept_se = coefs[1L, 2L],
      slope_se     = coefs[2L, 2L],
      cov_xy       = vcov(fit)[1L, 2L],
      intercept_ci = coefs[1L, 1L] + c(-1, 1) * t_val * coefs[1L, 2L],
      slope_ci     = coefs[2L, 1L] + c(-1, 1) * t_val * coefs[2L, 2L],
      sigma        = s$sigma,
      r_squared    = s$r.squared,
      residuals    = residuals(fit),
      lambda       = NA_real_,
      weights_spec = weights,
      n            = x$n,
      conf.level   = conf.level
    )

  } else if (method == "deming") {
    if (!is.null(w))
      stop("Weights are not supported for Deming regression. ",
           "Use method = \"wdeming\" for weighted Deming.", call. = FALSE)
    result <- .deming_fit(x$candidate, x$reference, lambda = lambda,
                          conf.level = conf.level)

  } else if (method == "wdeming") {
    if (is.null(w))
      stop("'weights' must be provided for Weighted Deming. ",
           "Use method = \"deming\" for unweighted regression.", call. = FALSE)
    result <- .wdeming_fit(x$candidate, x$reference, lambda = lambda,
                           weights = w, conf.level = conf.level)
    result$weights_spec <- weights

  } else if (method == "pb") {
    if (!is.null(w))
      warning("Weights are ignored for Passing-Bablok regression.", call. = FALSE)
    result <- .pb_fit(x$candidate, x$reference, conf.level = conf.level)
  }

  x$regression <- structure(result, class = "mcr_regression")
  print(x$regression)
  invisible(x)
}


#' Outlier detection (S3 method)
#'
#' Perform outlier detection based on the difference or percent difference between two measurements.
#' Reuses four methods from ../precision/outliers.R.
#'
#' @param x      mcr object
#' @param method Outlier detection method: "grubbs" (default), "esd", "dixon", "iqr"
#' @param type   Data type to compute: "difference" (default) or "percent" (percent difference)
#' @param alpha  Significance level, default 0.05 (Grubbs/ESD/Dixon only)
#' @param coef   IQR multiplier, default 1.5 (IQR only)
#' @param ...    Additional arguments passed to esd_test / dixon_test
#'
#' @return Updated mcr object (invisible), results stored in $outlier
#'
#' @examples
#'   obj <- mcr(ivd_mcr_example, "sid", "test", "ref")
#'   outlier(obj, method = "grubbs")
#'   outlier(obj, method = "iqr", type = "percent")
#' @export
outlier.mcr <- function(x, method = c("grubbs", "esd", "dixon", "iqr"),
                         type = c("difference", "percent"),
                         alpha = 0.05, coef = 1.5, ...) {

  if (!inherits(x, "mcr"))
    stop("Input must be an 'mcr' object.")

  method <- match.arg(method)
  type   <- match.arg(type)

  if (x$n < 3L)
    stop("Need at least 3 complete pairs for outlier detection, got ", x$n, ".")

  # Compute difference/percent difference
  if (type == "difference") {
    d     <- x$candidate - x$reference
    label <- sprintf("Difference (%s - %s)", x$candidate_name, x$reference_name)
  } else {
    d     <- (x$candidate - x$reference) / .safe_div(x$reference) * 100
    label <- sprintf("Percent diff ((%s - %s) / %s * 100)",
                     x$candidate_name, x$reference_name, x$reference_name)
  }

  # Call outliers_test (requires data.frame + column name)
  tmp_data <- data.frame(.mcr_diff = d, check.names = FALSE)
  raw <- switch(method,
    grubbs = outliers_test(tmp_data, ".mcr_diff", method = "grubbs", alpha = alpha),
    esd    = outliers_test(tmp_data, ".mcr_diff", method = "esd", alpha = alpha, ...),
    dixon  = outliers_test(tmp_data, ".mcr_diff", method = "dixon", alpha = alpha, ...),
    iqr    = outliers_test(tmp_data, ".mcr_diff", method = "iqr", coef = coef)
  )

  # Map back to original data row numbers
  n_out <- raw$n_outliers
  idx <- raw$indices
  if (n_out > 0 && length(idx) > 0) {
    orig_rows <- x$complete_idx[idx]
  } else {
    orig_rows <- integer(0)
    n_out <- 0L
  }

  # Storage: adapt to outliers_test return structure
  statistic <- if (method == "esd") raw$details$R %||% NA_real_
               else raw$details$statistic %||% NA_real_
  critical  <- raw$details$critical %||% NA_real_

  result <- structure(list(
    method     = method,
    data_type  = type,
    data_label = label,
    n_out      = n_out,
    indices    = orig_rows,
    values     = raw$values %||% numeric(0),
    statistic  = statistic,
    critical   = critical,
    alpha      = alpha,
    coef       = coef
  ), class = "mcr_outlier")
  x$outlier <- result

  print(result)
  invisible(x)
}


#' Bland-Altman analysis (S3 method)
#'
#' Calculate Limits of Agreement between two measurement methods,
#' supporting three y-axis metrics: difference, ratio, and percent difference.
#'
#' @param x           mcr object
#' @param type        Y-axis metric: "difference" (default),
#'                    "ratio" or "percent"
#' @param x_axis      X-axis: "mean" (average of the two methods, default), "candidate" (test method values),
#'                    "reference" (reference method values)
#' @param agree.level Agreement level for limits of agreement, default 0.95 (i.e., 95% LoA)
#' @param conf.level  Confidence level for LoA confidence intervals, default 0.95
#' @param ...         Additional arguments
#'
#' @return Updated mcr object (invisible), results stored in $bland_altman
#'
#' @examples
#'   obj <- mcr(ivd_mcr_example, "sid", "test", "ref")
#'   bland_altman(obj)
#'   bland_altman(obj, type = "ratio")
#'   bland_altman(obj, type = "percent", x_axis = "reference")
#' @export
bland_altman.mcr <- function(x, type = c("difference", "ratio", "percent"),
                              x_axis = c("mean", "candidate", "reference"),
                              agree.level = 0.95, conf.level = 0.95, ...) {

  if (!inherits(x, "mcr"))
    stop("Input must be an 'mcr' object.")

  type   <- match.arg(type)
  x_axis <- match.arg(x_axis)

  if (x$n < 3L)
    stop("Need at least 3 complete pairs for Bland-Altman analysis, got ", x$n, ".")

  # Parameter range validation
  if (!is.numeric(agree.level) || length(agree.level) != 1L ||
      is.na(agree.level) || agree.level <= 0 || agree.level >= 1)
    stop("'agree.level' must be a single number in (0, 1).", call. = FALSE)
  if (!is.numeric(conf.level) || length(conf.level) != 1L ||
      is.na(conf.level) || conf.level <= 0 || conf.level >= 1)
    stop("'conf.level' must be a single number in (0, 1).", call. = FALSE)

  # Compute x-axis
  means <- (x$candidate + x$reference) / 2
  x_vals <- switch(x_axis,
    mean      = means,
    candidate = x$candidate,
    reference = x$reference
  )

  # Compute y-axis
  y_vals <- switch(type,
    difference = x$candidate - x$reference,
    ratio      = x$candidate / .safe_div(x$reference),
    percent    = (x$candidate - x$reference) / .safe_div(x$reference) * 100
  )

  # Limits of agreement
  n <- length(y_vals)
  mean_diff <- mean(y_vals)
  sd_diff   <- sd(y_vals)
  z_agree   <- qnorm(1 - (1 - agree.level) / 2)

  loa_lower <- mean_diff - z_agree * sd_diff
  loa_upper <- mean_diff + z_agree * sd_diff

  # LoA confidence interval (Bland & Altman 1999)
  se_loa <- sqrt(sd_diff^2 * (1 / n + z_agree^2 / (2 * (n - 1))))
  t_val  <- qt(1 - (1 - conf.level) / 2, n - 1)

  loa_lower_ci <- c(loa_lower - t_val * se_loa, loa_lower + t_val * se_loa)
  loa_upper_ci <- c(loa_upper - t_val * se_loa, loa_upper + t_val * se_loa)

  # Labels
  y_label <- switch(type,
    difference = sprintf("%s - %s", x$candidate_name, x$reference_name),
    ratio      = sprintf("%s / %s", x$candidate_name, x$reference_name),
    percent    = sprintf("(%s - %s) / %s * 100", x$candidate_name, x$reference_name, x$reference_name)
  )
  x_label <- switch(x_axis,
    mean      = sprintf("Mean of %s and %s", x$candidate_name, x$reference_name),
    candidate = x$candidate_name,
    reference = x$reference_name
  )

  # Storage
  result <- list(
    type        = type,
    x_axis      = x_axis,
    n           = n,
    mean_diff   = mean_diff,
    sd_diff     = sd_diff,
    loa         = c(lower = loa_lower, upper = loa_upper),
    loa_ci      = list(
      lower = loa_lower_ci,
      upper = loa_upper_ci
    ),
    agree.level = agree.level,
    conf.level  = conf.level,
    y_label     = y_label,
    x_label     = x_label,
    x_vals      = x_vals,   # for plot
    y_vals      = y_vals    # for plot
  )
  x$bland_altman <- structure(result, class = "mcr_bland_altman")
  print(x$bland_altman)
  invisible(x)
}


#' Predict (S3 method) -- predict based on regression results
#'
#' Predict values based on stored regression results.
#'
#' @param object     mcr object (must call regression() first)
#' @param newdata    data.frame containing predictor variables. If provided, candidate and
#'                   reference are treated as column names in newdata.
#' @param candidate  Predictor variable. When newdata is not NULL, it is a column name (character) in newdata;
#'                   when newdata is NULL, it is a numeric vector; if also NULL, uses original data.
#' @param reference  Predictor for inverse prediction (only used when inverse=TRUE). Usage same as candidate.
#' @param inverse    Whether to perform inverse prediction (reference to candidate), default FALSE.
#' @param interval   Interval type: "none" (default), "confidence", "prediction", "both".
#'                   Only forward prediction (inverse=FALSE) supports intervals.
#' @param conf.level Confidence level, default 0.95
#' @param ...        Additional arguments
#'
#' @return data.frame containing predicted values and (if requested) interval bounds
#'
#' @examples
#'   obj <- mcr(ivd_mcr_example, "sid", "test", "ref")
#'   obj <- regression(obj, method = "ols")
#'   predict(obj, candidate = c(40, 50, 60))
#'   predict(obj, candidate = c(40, 50, 60), interval = "both")
#'   predict(obj, newdata = data.frame(xx = c(40, 50)), candidate = "xx")
#'   predict(obj, inverse = TRUE)  # Inverse prediction on original data
#' @export
predict.mcr <- function(object, newdata = NULL,
                         candidate = NULL, reference = NULL,
                         inverse = FALSE,
                         interval = c("none", "confidence", "prediction", "both"),
                         conf.level = 0.95, ...) {

  if (!inherits(object, "mcr"))
    stop("Input must be an 'mcr' object.")
  if (is.null(object$regression))
    stop("Run regression() first before predict().")

  rg <- object$regression
  interval <- match.arg(interval)

  # Determine input values
  newdata_provided <- !is.null(newdata)

  if (newdata_provided) {
    # newdata mode: candidate/reference are column names
    if (!is.data.frame(newdata))
      stop("'newdata' must be a data.frame.")
  }

  # Inverse prediction (reference to candidate)
  if (inverse) {
    if (abs(rg$slope) < .Machine$double.eps)
      stop("Slope is near zero; cannot perform inverse prediction.")

    if (newdata_provided) {
      ref_col <- if (!is.null(reference)) reference else object$reference_name
      if (!ref_col %in% names(newdata))
        stop("Column '", ref_col, "' not found in newdata.")
      ref_vals <- newdata[[ref_col]]
    } else {
      ref_vals <- if (!is.null(reference)) reference else object$reference
    }

    cand_pred <- (ref_vals - rg$intercept) / rg$slope
    result <- data.frame(reference = ref_vals, cand_pred = cand_pred)

    return(result)
  }

  # Forward prediction (candidate to reference)
  if (newdata_provided) {
    cand_col <- if (!is.null(candidate)) candidate else object$candidate_name
    if (!cand_col %in% names(newdata))
      stop("Column '", cand_col, "' not found in newdata.")
    cand_vals <- newdata[[cand_col]]
  } else {
    cand_vals <- if (!is.null(candidate)) candidate else object$candidate
  }

  if (!is.numeric(cand_vals))
    stop("Input values must be numeric.")

  pred <- rg$intercept + rg$slope * cand_vals
  result <- data.frame(candidate = cand_vals, ref_pred = pred)

  if (interval != "none" && !is.na(rg$slope_se) && is.finite(rg$slope_se)) {
    n <- rg$n
    se_fit <- sqrt(rg$intercept_se^2 +
                   cand_vals^2 * rg$slope_se^2 +
                   2 * cand_vals * rg$cov_xy)
    t_val <- qt(1 - (1 - conf.level) / 2, n - 2)

    if (interval %in% c("confidence", "both")) {
      result$ci_lower <- pred - t_val * se_fit
      result$ci_upper <- pred + t_val * se_fit
    }
    if (interval %in% c("prediction", "both")) {
      se_pred <- sqrt(se_fit^2 + rg$sigma^2)
      result$pi_lower <- pred - t_val * se_pred
      result$pi_upper <- pred + t_val * se_pred
    }
  }

  result
}


#' Bias analysis (S3 method) -- estimate bias at given medical decision levels
#'
#' Compute bias at specified medical decision levels (MDL) based on stored regression results:
#'   bias = candidate - predicted_reference
#'        = x0 - (intercept + slope * x0)
#'        = -intercept + (1 - slope) * x0
#'
#' Bias is the difference between the candidate method value and the estimated reference method
#' value; a positive value indicates the candidate method is higher.
#'
#' @param x        mcr object (must call regression() first)
#' @param mdl      Medical decision levels (numeric vector), i.e., values of the test method
#' @param level    Confidence level, default 0.95
#' @param interval Interval type: "" (point estimate, default), "confidence" (confidence interval),
#'                 "prediction" (prediction interval), "both" (confidence + prediction)
#' @param ...      Additional arguments (currently unused).
#'
#' @return Updated mcr object (invisible), results stored in $bias
#'
#' @examples
#'   obj <- mcr(ivd_mcr_example, "sid", "test", "ref")
#'   obj <- regression(obj, method = "ols")
#'   bias(obj, mdl = c(200, 400, 600))
#'   bias(obj, mdl = c(200, 400, 600), interval = "both")
#' @export
bias.mcr <- function(x, mdl, level = 0.95,
                      interval = c("", "confidence", "prediction", "both"),
                      ...) {

  if (!inherits(x, "mcr"))
    stop("Input must be an 'mcr' object.")
  if (is.null(x$regression))
    stop("Run regression() first before bias().")

  rg <- x$regression
  interval <- match.arg(interval)
  use_interval <- interval != ""

  if (missing(mdl) || is.null(mdl))
    stop("'mdl' must be provided (medical decision level(s)).")
  if (!is.numeric(mdl))
    stop("'mdl' must be numeric.")

  # Compute bias: bias = candidate - predicted_reference
  pred_ref <- rg$intercept + rg$slope * mdl
  bias_val <- mdl - pred_ref  # = -intercept + (1 - slope) * mdl

  result <- data.frame(mdl = mdl, bias = bias_val)

  # Interval estimation
  if (use_interval && !is.na(rg$slope_se) && is.finite(rg$slope_se)) {
    n <- rg$n
    # Var(bias) = Var(intercept) + mdl² * Var(slope) + 2 * mdl * Cov(i,s)
    se_bias <- sqrt(rg$intercept_se^2 +
                    mdl^2 * rg$slope_se^2 +
                    2 * mdl * rg$cov_xy)
    t_val <- qt(1 - (1 - level) / 2, n - 2)

    if (interval %in% c("confidence", "both")) {
      result$ci_lower <- bias_val - t_val * se_bias
      result$ci_upper <- bias_val + t_val * se_bias
    }
    if (interval %in% c("prediction", "both")) {
      se_pred <- sqrt(se_bias^2 + rg$sigma^2)
      result$pi_lower <- bias_val - t_val * se_pred
      result$pi_upper <- bias_val + t_val * se_pred
    }
  }

  # Store with metadata attributes
  result <- structure(result,
    class = c("mcr_bias", "data.frame"),
    method   = rg$method,
    interval = interval,
    level    = level
  )
  x$bias <- result
  print(result)
  invisible(x)
}


#' Plot (S3 method) -- unified plotting interface
#'
#' Draw one of four plot types for an mcr object.
#'
#' @param x          mcr object
#' @param type       Plot type: "scatter" (scatter + identity line, default),
#'                   "regression" (regression line + confidence/prediction bands),
#'                   "bland_altman" (Bland-Altman plot),
#'                   "bias" (bias trend plot)
#' @param interval   Interval type (only for type="regression"): "none" (default),
#'                   "confidence", "prediction", "both"
#' @param conf.level Confidence level; if NULL, reads from analysis slot, otherwise uses this value
#' @param mdl        Medical decision levels (only for type="bias"); if NULL, tries to read
#'                   from x$bias$mdl
#' @param ...        Additional arguments
#'
#' @return Invisible ggplot object
#'
#' @examples
#'   obj <- mcr(ivd_mcr_example, "sid", "test", "ref")
#'   plot(obj)
#'   plot(obj, type = "scatter")
#'   # Analyses must be performed first:
#'   # obj <- regression(obj)
#'   # plot(obj, type = "regression", interval = "confidence")
#'   # obj <- bland_altman(obj)
#'   # plot(obj, type = "bland_altman")
#'   # obj <- bias(obj, mdl = c(200, 400))
#'   # plot(obj, type = "bias")
#' @export
plot.mcr <- function(x,
                     type = c("scatter", "regression", "bland_altman", "bias"),
                     interval = c("none", "confidence", "prediction", "both"),
                     conf.level = NULL, mdl = NULL, ...) {

  if (!inherits(x, "mcr"))
    stop("Input must be an 'mcr' object.")

  type <- match.arg(type)
  interval <- match.arg(interval)
  .require_pkg("ggplot2")

  #
  # Scatter plot + identity line
  #
  if (type == "scatter") {
    df <- data.frame(xv = x$reference, yv = x$candidate)
    x_range <- range(x$candidate, x$reference, na.rm = TRUE)

    p <- ggplot2::ggplot(df, ggplot2::aes(x = .data$xv, y = .data$yv)) +
      ggplot2::geom_point(size = 2, na.rm = TRUE) +
      ggplot2::geom_abline(slope = 1, intercept = 0,
                           linetype = "dashed", color = "gray50", linewidth = 0.5) +
      ggplot2::coord_fixed(xlim = x_range, ylim = x_range) +
      ggplot2::labs(x = x$reference_name, y = x$candidate_name,
                    title = "Scatter Plot") +
      ggplot2::theme_bw() +
      ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5))

    print(p)
    return(invisible(p))
  }

  #
  # Regression plot
  #
  if (type == "regression") {
    rg <- x$regression
    if (is.null(rg))
      stop("Run regression() first before plot(type = 'regression').", call. = FALSE)

    cl <- conf.level %||% rg$conf.level %||% 0.95

    # Regression line: candidate = (reference - intercept) / slope
    ref_seq <- seq(min(x$reference), max(x$reference), length.out = 200)
    cand_pred <- (ref_seq - rg$intercept) / rg$slope

    df <- data.frame(xv = x$reference, yv = x$candidate)
    plot_df <- data.frame(x = ref_seq, y = cand_pred)

    show_ci <- interval %in% c("confidence", "both")
    show_pi <- interval %in% c("prediction", "both")
    has_se  <- !is.na(rg$slope_se) && is.finite(rg$slope_se)

    p <- ggplot2::ggplot(df, ggplot2::aes(x = .data$xv, y = .data$yv)) +
      ggplot2::geom_point(size = 2, na.rm = TRUE) +
      ggplot2::geom_abline(slope = 1, intercept = 0,
                           linetype = "dashed", color = "gray50", linewidth = 0.5)

    if ((show_ci || show_pi) && has_se) {
      n <- rg$n
      t_val <- qt(1 - (1 - cl) / 2, n - 2)
      cand_at_ref <- cand_pred
      se_ref <- sqrt(rg$intercept_se^2 +
                     cand_at_ref^2 * rg$slope_se^2 +
                     2 * cand_at_ref * rg$cov_xy)
      se_cand <- se_ref / abs(rg$slope)

      if (show_ci) {
        ci_lower <- cand_pred - t_val * se_cand
        ci_upper <- cand_pred + t_val * se_cand
        p <- p + ggplot2::geom_ribbon(
          data = data.frame(x = ref_seq, ymin = ci_lower, ymax = ci_upper),
          inherit.aes = FALSE,
          ggplot2::aes(x = x, ymin = ymin, ymax = ymax),
          fill = "steelblue", alpha = 0.2)
      }
      if (show_pi) {
        se_pred <- sqrt(se_cand^2 + rg$sigma^2 / rg$slope^2)
        pi_lower <- cand_pred - t_val * se_pred
        pi_upper <- cand_pred + t_val * se_pred
        p <- p + ggplot2::geom_ribbon(
          data = data.frame(x = ref_seq, ymin = pi_lower, ymax = pi_upper),
          inherit.aes = FALSE,
          ggplot2::aes(x = x, ymin = ymin, ymax = ymax),
          fill = "gray40", alpha = 0.1)
      }
    }

    p <- p +
      ggplot2::geom_line(data = plot_df, inherit.aes = FALSE,
                         ggplot2::aes(x = x, y = y),
                         color = "steelblue", linewidth = 1) +
      ggplot2::labs(x = x$reference_name, y = x$candidate_name,
                    title = paste0(rg$method, " Regression")) +
      ggplot2::theme_bw() +
      ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5))

    print(p)
    return(invisible(p))
  }

  #
  # Bland-Altman plot
  #
  if (type == "bland_altman") {
    ba <- x$bland_altman
    if (is.null(ba))
      stop("Run bland_altman() first before plot(type = 'bland_altman').", call. = FALSE)

    x_vals <- ba$x_vals
    y_vals <- ba$y_vals
    mean_diff <- ba$mean_diff
    loa_lower <- ba$loa[1L]
    loa_upper <- ba$loa[2L]

    loa_lower_ci <- if (!is.null(ba$loa_ci$lower)) ba$loa_ci$lower else c(NA, NA)
    loa_upper_ci <- if (!is.null(ba$loa_ci$upper)) ba$loa_ci$upper else c(NA, NA)

    df <- data.frame(xv = x_vals, yv = y_vals)
    x_rng <- range(x_vals, na.rm = TRUE)

    ribbon_df <- data.frame(
      x = c(x_rng[1L], x_rng[2L]),
      loa_lower_lo = loa_lower_ci[1L],
      loa_lower_hi = loa_lower_ci[2L],
      loa_upper_lo = loa_upper_ci[1L],
      loa_upper_hi = loa_upper_ci[2L]
    )

    p <- ggplot2::ggplot(df, ggplot2::aes(x = .data$xv, y = .data$yv)) +
      ggplot2::geom_point(size = 2, na.rm = TRUE) +
      ggplot2::geom_ribbon(data = ribbon_df, inherit.aes = FALSE,
                           ggplot2::aes(x = x, ymin = loa_lower_lo, ymax = loa_lower_hi),
                           fill = "steelblue", alpha = 0.15) +
      ggplot2::geom_ribbon(data = ribbon_df, inherit.aes = FALSE,
                           ggplot2::aes(x = x, ymin = loa_upper_lo, ymax = loa_upper_hi),
                           fill = "steelblue", alpha = 0.15) +
      ggplot2::geom_hline(yintercept = mean_diff,
                           color = "steelblue", linewidth = 1) +
      ggplot2::geom_hline(yintercept = loa_lower,
                           linetype = "dashed", color = "steelblue", linewidth = 0.8) +
      ggplot2::geom_hline(yintercept = loa_upper,
                           linetype = "dashed", color = "steelblue", linewidth = 0.8) +
      ggplot2::geom_hline(yintercept = if (ba$type == "ratio") 1 else 0,
                           linetype = "dotted", color = "gray50", linewidth = 0.5) +
      ggplot2::labs(x = ba$x_label, y = ba$y_label,
                    title = "Bland-Altman Plot") +
      ggplot2::theme_bw() +
      ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5))

    label_y <- max(y_vals, na.rm = TRUE)
    p <- p + ggplot2::annotate("text",
                                x = min(x_vals, na.rm = TRUE),
                                y = label_y,
                                label = sprintf("Mean = %s", .format_num(mean_diff)),
                                hjust = 0, vjust = 1.5, size = 3.5)
    print(p)
    return(invisible(p))
  }

  #
  # Bias trend plot
  #
  if (type == "bias") {
    rg <- x$regression
    if (is.null(rg))
      stop("Run regression() first before plot(type = 'bias').", call. = FALSE)

    cl <- conf.level %||% rg$conf.level %||% 0.95

    # Cover the entire data range
    x_range <- range(x$candidate, na.rm = TRUE)
    x_seq <- seq(x_range[1L], x_range[2L], length.out = 200)
    pred_ref_seq <- rg$intercept + rg$slope * x_seq
    bias_seq <- x_seq - pred_ref_seq

    plot_df <- data.frame(x = x_seq, bias = bias_seq)

    p <- ggplot2::ggplot(plot_df, ggplot2::aes(x = .data$x, y = .data$bias)) +
      ggplot2::geom_hline(yintercept = 0, linetype = "dotted",
                           color = "gray50", linewidth = 0.5) +
      ggplot2::geom_line(color = "steelblue", linewidth = 1)


    # Confidence / prediction bands
    show_ci <- interval %in% c("confidence", "both")
    show_pi <- interval %in% c("prediction", "both")
    has_se  <- !is.na(rg$slope_se) && is.finite(rg$slope_se)

    if ((show_ci || show_pi) && has_se) {
      n <- rg$n
      se_bias <- sqrt(rg$intercept_se^2 +
                      x_seq^2 * rg$slope_se^2 +
                      2 * x_seq * rg$cov_xy)
      t_val <- qt(1 - (1 - cl) / 2, n - 2)

      if (show_ci) {
        ci_lower <- bias_seq - t_val * se_bias
        ci_upper <- bias_seq + t_val * se_bias
        ribbon_ci <- data.frame(x = x_seq, ymin = ci_lower, ymax = ci_upper)
        p <- p + ggplot2::geom_ribbon(
          data = ribbon_ci,
          inherit.aes = FALSE,
          ggplot2::aes(x = x, ymin = ymin, ymax = ymax),
          fill = "steelblue", alpha = 0.2)
      }
      if (show_pi) {
        se_pred <- sqrt(se_bias^2 + rg$sigma^2)
        pi_lower <- bias_seq - t_val * se_pred
        pi_upper <- bias_seq + t_val * se_pred
        ribbon_pi <- data.frame(x = x_seq, ymin = pi_lower, ymax = pi_upper)
        p <- p + ggplot2::geom_ribbon(
          data = ribbon_pi,
          inherit.aes = FALSE,
          ggplot2::aes(x = x, ymin = ymin, ymax = ymax),
          fill = "gray40", alpha = 0.1)
      }
    }

    # Annotate MDL points: prefer x$bias$mdl, fall back to mdl argument
    mdl_vals <- x$bias$mdl %||% mdl
    if (!is.null(mdl_vals)) {
      bias_at_mdl <- mdl_vals - (rg$intercept + rg$slope * mdl_vals)
      point_df <- data.frame(x = mdl_vals, bias = bias_at_mdl)
      p <- p + ggplot2::geom_point(data = point_df, inherit.aes = FALSE,
                                    ggplot2::aes(x = x, y = bias),
                                    color = "darkorange", size = 3)
    }

    p <- p +
      ggplot2::labs(x = x$candidate_name,
                    y = sprintf("Bias (%s - %s)", x$candidate_name, x$reference_name),
                    title = paste0("Bias Plot (", rg$method, ")")) +
      ggplot2::theme_bw() +
      ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5))

    print(p)
    return(invisible(p))
  }
}
