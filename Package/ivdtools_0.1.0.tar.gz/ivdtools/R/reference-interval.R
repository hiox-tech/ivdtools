#' Reference Interval (RI) Analysis
#'
#' Features:
#'   1. Reference interval calculation (CLSI EP28-A3c)
#'   2. Three methods: percentile (non-parametric), parametric (normal), robust (Horn & Pesce)
#'   3. Data quality report: missing values, duplicate IDs
#'   4. Visualization: jitter strip plot + method reference intervals with CI
#'
#' Dependencies: base R + ggplot2
#'
#' @param data     A data frame.
#' @param col      Column name (character) of the numeric variable.
#' @param interval Reference interval coverage, default 0.95 (i.e. 2.5%--97.5%).
#' @param ci       Confidence level for the reference limits, default 0.95.
#' @param method   Calculation method(s):
#'                "percentile" (default), "parametric", "robust",
#'                or "all" for all three. Multiple methods can be passed as a vector.
#' @param id       Optional column name for ID-based duplicate detection.
#'
#' @return An object of S3 class "reference_interval" with fields:
#'   $call, $col, $id_name, $n_total, $n_miss, $n_complete,
#'   $n_duplicates, $dup_rows, $interval, $ci, $methods,
#'   $percentile, $parametric, $robust, $values
#'
#' @examples
#'   df <- data.frame(val = rnorm(200, 100, 15))
#'   reference_interval(df, "val")
#'   reference_interval(df, "val", method = "all")
#'   reference_interval(df, "val", method = c("percentile", "robust"))
#'
#' @importFrom stats quantile qnorm sd mad median shapiro.test qt
#' @importFrom ggplot2 ggplot aes geom_boxplot geom_jitter geom_linerange
#'   geom_point geom_errorbar scale_color_manual scale_x_discrete labs
#'   theme_bw theme element_text margin position_dodge
#' @export
reference_interval <- function(data, col, interval = 0.95, ci = 0.95,
                                method = "percentile", id = NULL) {

  # Format numeric values
  .format_num <- function(x, digits = 4L) {
    formatC(x, format = "f", digits = digits)
  }

  # NULL coalescing operator
  `%||%` <- function(a, b) if (is.null(a)) b else a

  # Rank-based confidence interval for quantiles (CLSI EP28-A3c Section 7.2)
  #
  # Uses normal approximation of the binomial distribution:
  #   r = n*p +/- z * sqrt(n * p * (1-p))
  .quantile_ci <- function(n, p, ci, sorted_values) {
    z <- stats::qnorm(1 - (1 - ci) / 2)
    r_lower <- max(1, floor(n * p - z * sqrt(n * p * (1 - p))))
    r_upper <- min(n, ceiling(n * p + z * sqrt(n * p * (1 - p))))
    list(
      lower      = sorted_values[r_lower],
      upper      = sorted_values[r_upper],
      rank_lower = r_lower,
      rank_upper = r_upper
    )
  }

  # Percentile method reference interval

  # Uses quantile(type=6) (CLSI EP28-A3c / SAS compatible),
  # with rank-based CI for the limits.
  .percentile_ri <- function(values, interval, ci) {
    n <- length(values)
    alpha <- (1 - interval) / 2
    sorted_vals <- sort(values)

    lower <- stats::quantile(values, alpha, type = 6)
    upper <- stats::quantile(values, 1 - alpha, type = 6)

    ci_low <- .quantile_ci(n, alpha, ci, sorted_vals)
    ci_up  <- .quantile_ci(n, 1 - alpha, ci, sorted_vals)

    list(
      method       = "Percentile",
      n            = n,
      lower        = as.numeric(lower),
      upper        = as.numeric(upper),
      ci_lower     = list(lower = ci_low$lower, upper = ci_low$upper,
                          rank = c(ci_low$rank_lower, ci_low$rank_lower)),
      ci_upper     = list(lower = ci_up$lower, upper = ci_up$upper,
                          rank = c(ci_up$rank_lower, ci_up$rank_lower)),
      quantile_type = 6L,
      alpha        = alpha
    )
  }

  # Parametric reference interval (normal distribution)

  # 1. Shapiro-Wilk normality test
  # 2. If p < 0.05, attempt log transformation; if still non-normal, warn and continue
  # 3. RI = mean +/- z * SD (z determined by interval)
  # 4. CI via SE(SD) formula from CLSI EP28-A3c
  .param_ri <- function(values, interval, ci) {
    n <- length(values)
    alpha <- (1 - interval) / 2
    z_val <- stats::qnorm(1 - alpha)

    # Normality test
    sw <- stats::shapiro.test(values)
    transformed <- FALSE
    transform_type <- "none"

    working_vals <- values
    if (sw$p.value < 0.05) {
      if (all(values > 0)) {
        log_vals <- log(values)
        sw_log <- tryCatch(stats::shapiro.test(log_vals), error = function(e) NULL)
        if (!is.null(sw_log) && sw_log$p.value >= 0.05) {
          working_vals <- log_vals
          transformed <- TRUE
          transform_type <- "log"
          sw <- sw_log
        } else {
          warning("Data not normal (Shapiro-Wilk p = ", .format_num(sw$p.value),
                  "). Log transformation also failed. ",
                  "Proceeding with original values.", call. = FALSE)
        }
      } else {
        warning("Data not normal (Shapiro-Wilk p = ", .format_num(sw$p.value),
                ") and log transformation not possible (non-positive values). ",
                "Proceeding with original values.", call. = FALSE)
      }
    }

    # Compute RI
    m <- mean(working_vals)
    s <- stats::sd(working_vals)

    lower <- m - z_val * s
    upper <- m + z_val * s

    # CI for reference limits (CLSI EP28-A3c)
    se_limit <- s * sqrt(1 / n + z_val^2 / (2 * n))
    t_df <- n - 2
    t_val <- stats::qt(1 - (1 - ci) / 2, df = max(t_df, 1))

    ci_low <- list(lower = lower - t_val * se_limit,
                   upper = lower + t_val * se_limit)
    ci_up  <- list(lower = upper - t_val * se_limit,
                   upper = upper + t_val * se_limit)

    # Back-transform if log-transformed
    if (transformed) {
      lower <- exp(lower)
      upper <- exp(upper)
      ci_low$lower <- exp(ci_low$lower)
      ci_low$upper <- exp(ci_low$upper)
      ci_up$lower  <- exp(ci_up$lower)
      ci_up$upper  <- exp(ci_up$upper)
    }

    list(
      method         = "Parametric",
      n              = n,
      lower          = lower,
      upper          = upper,
      ci_lower       = ci_low,
      ci_upper       = ci_up,
      mean           = if (transformed) exp(m) else m,
      sd             = if (transformed) NA_real_ else s,
      shapiro_wilk   = list(W = sw$statistic, p = sw$p.value),
      transformed    = transformed,
      transform_type = transform_type,
      z_value        = z_val,
      alpha          = alpha
    )
  }

  # Robust reference interval (Horn & Pesce)

  # Manual Huber M-estimator for robust mean and robust SD (MAD),
  # bootstrap for CI of the limits.
  .robust_ri <- function(values, interval, ci) {
    n <- length(values)
    alpha <- (1 - interval) / 2
    z_val <- stats::qnorm(1 - alpha)
    k <- 1.5

    # Manual Huber M-estimation
    T_est <- stats::median(values)
    S_est <- stats::mad(values, constant = 1 / 0.6745)
    n_iter <- 0L
    repeat {
      n_iter <- n_iter + 1L
      u <- (values - T_est) / S_est
      w <- ifelse(abs(u) <= k, 1, k / abs(u))
      T_new <- sum(w * values) / sum(w)
      S_new <- sqrt(sum(w * (values - T_new)^2) / max(n - 1, 1))
      if (abs(T_new - T_est) < 1e-8 && abs(S_new - S_est) < 1e-8) break
      if (n_iter > 100) {
        warning("Huber M-estimation did not converge after 100 iterations.",
                call. = FALSE)
        break
      }
      T_est <- T_new
      S_est <- S_new
    }
    robust_mean <- T_est
    robust_sd   <- S_est

    lower <- robust_mean - z_val * robust_sd
    upper <- robust_mean + z_val * robust_sd

    # Bootstrap CI
    B <- 1999
    boot_lower <- numeric(B)
    boot_upper <- numeric(B)

    for (i in seq_len(B)) {
      boot_x <- values[sample.int(n, n, replace = TRUE)]
      b_T <- stats::median(boot_x)
      b_S <- stats::mad(boot_x, constant = 1 / 0.6745)
      for (j in seq_len(50)) {
        bu <- (boot_x - b_T) / b_S
        bw <- ifelse(abs(bu) <= k, 1, k / abs(bu))
        b_T_new <- sum(bw * boot_x) / sum(bw)
        b_S_new <- sqrt(sum(bw * (boot_x - b_T_new)^2) / max(length(boot_x) - 1, 1))
        if (abs(b_T_new - b_T) < 1e-8 && abs(b_S_new - b_S) < 1e-8) break
        b_T <- b_T_new
        b_S <- b_S_new
      }
      boot_lower[i] <- b_T - z_val * b_S
      boot_upper[i] <- b_T + z_val * b_S
    }

    ci_low <- list(
      lower = stats::quantile(boot_lower, (1 - ci) / 2),
      upper = stats::quantile(boot_lower, 1 - (1 - ci) / 2)
    )
    ci_up <- list(
      lower = stats::quantile(boot_upper, (1 - ci) / 2),
      upper = stats::quantile(boot_upper, 1 - (1 - ci) / 2)
    )

    list(
      method         = "Robust",
      n              = n,
      lower          = lower,
      upper          = upper,
      ci_lower       = ci_low,
      ci_upper       = ci_up,
      robust_mean    = robust_mean,
      robust_sd      = robust_sd,
      algorithm      = paste0("Huber M-estimation (k=", k, ", ", n_iter, " iter) + MAD"),
      bootstrap_reps = B,
      z_value        = z_val,
      alpha          = alpha
    )
  }

  # Input validation

  if (!is.data.frame(data))
    stop("'data' must be a data frame.", call. = FALSE)
  if (!is.character(col) || length(col) != 1L || !col %in% names(data))
    stop("'col' must be a single column name in 'data'.", call. = FALSE)
  if (!is.numeric(data[[col]]))
    stop("Column '", col, "' must be numeric.", call. = FALSE)
  if (!is.numeric(interval) || length(interval) != 1L || interval <= 0 || interval >= 1)
    stop("'interval' must be a single number in (0, 1).", call. = FALSE)
  if (!is.numeric(ci) || length(ci) != 1L || ci <= 0 || ci >= 1)
    stop("'ci' must be a single number in (0, 1).", call. = FALSE)
  if (!is.null(id) && (!is.character(id) || length(id) != 1L || !id %in% names(data)))
    stop("'id' must be NULL or a single column name in 'data'.", call. = FALSE)

  # Parse method

  valid_methods <- c("percentile", "parametric", "robust")
  if (is.character(method) && length(method) == 1L && method == "all") {
    methods <- valid_methods
  } else {
    bad <- setdiff(method, valid_methods)
    if (length(bad) > 0)
      stop("Invalid method(s): ", paste(bad, collapse = ", "),
           ". Valid: ", paste(valid_methods, collapse = ", "), call. = FALSE)
    methods <- unique(method)
  }

  # Missing value detection

  n_total <- nrow(data)
  miss_idx <- which(is.na(data[[col]]) | !is.finite(data[[col]]))
  n_miss <- length(miss_idx)
  values_cc <- data[[col]][is.finite(data[[col]])]
  n_complete <- length(values_cc)

  if (n_complete < 3)
    stop("Need at least 3 complete observations, but only ", n_complete,
         " available.", call. = FALSE)

  if (n_complete < 20)
    warning("Only ", n_complete, " complete observations. ",
            "CLSI EP28-A3c recommends >= 120 for percentile method ",
            "and >= 40 for parametric method.", call. = FALSE)

  # Zero-variance check

  if (length(unique(values_cc)) < 2)
    stop("Zero variance in data; cannot compute reference interval.", call. = FALSE)

  # ID duplicate detection

  n_duplicates <- 0L
  dup_rows <- integer(0)
  id_name <- id %||% "--"
  if (!is.null(id)) {
    id_values_cc <- data[[id]][is.finite(data[[col]])]
    dups <- duplicated(id_values_cc) | duplicated(id_values_cc, fromLast = TRUE)
    n_duplicates <- sum(dups)
    dup_rows <- which(is.finite(data[[col]]))[dups]
  }

  # Compute selected methods

  result_percentile <- NULL
  result_parametric  <- NULL
  result_robust      <- NULL

  if ("percentile" %in% methods) {
    result_percentile <- .percentile_ri(values_cc, interval, ci)
  }
  if ("parametric" %in% methods) {
    result_parametric <- .param_ri(values_cc, interval, ci)
  }
  if ("robust" %in% methods) {
    result_robust <- .robust_ri(values_cc, interval, ci)
  }

  # Build return object

  out <- list(
    call          = match.call(),
    col           = col,
    id_name       = id_name,
    n_total       = n_total,
    n_miss        = n_miss,
    n_complete    = n_complete,
    n_duplicates  = n_duplicates,
    dup_rows      = dup_rows,
    values        = values_cc,
    interval      = interval,
    ci            = ci,
    methods       = methods,
    percentile    = result_percentile,
    parametric    = result_parametric,
    robust        = result_robust
  )
  class(out) <- "reference_interval"

  out
}


# S3 print method

#' Print reference interval analysis results
#'
#' @param x    A "reference_interval" object.
#' @param ...  Additional arguments (reserved for generic).
#'
#' @export
print.reference_interval <- function(x, ...) {
  alpha <- (1 - x$interval) / 2

  cat("\nReference Interval Analysis\n")
  cat(sprintf("  %-20s %s\n", "Column:", x$col))
  cat(sprintf("  %-20s %s%% (alpha = %.3f)\n", "Reference interval:", x$interval * 100, alpha))
  cat(sprintf("  %-20s %s\n", "Confidence level:", x$ci))
  cat(sprintf("  %-20s %s\n", "ID variable:", x$id_name))
  cat(sprintf("  %-20s %d / %d\n", "Complete cases:", x$n_complete, x$n_total))
  cat("\n")

  # Missing values
  if (x$n_miss > 0) {
    cat(sprintf("  Missing values: %d / %d rows excluded\n", x$n_miss, x$n_total))
  } else {
    cat("  No missing values.\n")
  }

  # Duplicate IDs
  if (x$id_name != "--") {
    if (x$n_duplicates > 0) {
      cat(sprintf("  Duplicate IDs: %d found at row(s): %s\n",
                  x$n_duplicates, paste(x$dup_rows, collapse = ", ")))
    } else {
      cat("  No duplicate IDs found.\n")
    }
  } else {
    cat("  Note: 'id' not provided, skip duplicate detection.\n")
  }

  # Sample size note
  if (x$n_complete < 120)
    cat(sprintf("  Note: %d observations (CLSI recommends >= 120 for percentile)\n", x$n_complete))

  # Per-method results
  all_results <- list(x$percentile, x$parametric, x$robust)
  for (res in all_results) {
    if (is.null(res)) next

    # Method description
    desc <- res$method
    if (res$method == "Percentile") {
      desc <- sprintf("Percentile (quantile type %d, CLSI EP28-A3c)", res$quantile_type)
    } else if (res$method == "Parametric") {
      sw <- res$shapiro_wilk
      norm_note <- if (res$transformed) {
        sprintf("log-transformed, Shapiro-Wilk p = %s", formatC(sw$p, format = "f", digits = 4))
      } else if (sw$p >= 0.05) {
        sprintf("Shapiro-Wilk p = %s, normal", formatC(sw$p, format = "f", digits = 4))
      } else {
        "WARNING: non-normal data"
      }
      desc <- sprintf("Parametric (%s)", norm_note)
    } else if (res$method == "Robust") {
      desc <- sprintf("Robust (%s)", res$algorithm)
    }

    cat("\n")
    cat(sprintf("  %s\n", desc))
    cat(sprintf("    Lower = %s  [%s, %s]\n",
                formatC(res$lower, format = "f", digits = 4),
                formatC(res$ci_lower$lower, format = "f", digits = 4),
                formatC(res$ci_lower$upper, format = "f", digits = 4)))
    cat(sprintf("    Upper = %s  [%s, %s]\n",
                formatC(res$upper, format = "f", digits = 4),
                formatC(res$ci_upper$lower, format = "f", digits = 4),
                formatC(res$ci_upper$upper, format = "f", digits = 4)))
  }
  cat("\n")

  invisible(x)
}


# S3 plot method

#' Plot reference interval results
#'
#' One panel per method: jitter strip chart overlaid with
#' reference interval limits, endpoints, and CI error bars.
#'
#' @param x    A "reference_interval" object.
#' @param ...  Additional arguments (reserved for generic).
#'
#' @export
plot.reference_interval <- function(x, ...) {

  values <- x$values
  col_name <- x$col
  methods <- x$methods

  method_colors <- c(
    percentile = "#2166AC",
    parametric = "#B2182B",
    robust     = "#4DAF4A"
  )
  color_labels <- c(
    percentile = "Percentile",
    parametric = "Parametric",
    robust     = "Robust"
  )

  # Build method limits data
  limits_list <- list()
  for (m in methods) {
    res <- x[[m]]
    if (is.null(res)) next
    limits_list[[length(limits_list) + 1L]] <- data.frame(
      method      = factor(unname(color_labels[m]), levels = color_labels[methods]),
      lower       = res$lower,
      upper       = res$upper,
      ci_lo_lower = res$ci_lower$lower,
      ci_lo_upper = res$ci_lower$upper,
      ci_up_lower = res$ci_upper$lower,
      ci_up_upper = res$ci_upper$upper,
      stringsAsFactors = FALSE
    )
  }
  limits_df <- do.call(rbind, limits_list)

  # Build data frame with one row per value per method (for jitter)
  data_list <- list()
  for (m in methods) {
    if (is.null(x[[m]])) next
    data_list[[length(data_list) + 1L]] <- data.frame(
      method = factor(unname(color_labels[m]), levels = color_labels[methods]),
      value  = as.numeric(values),
      stringsAsFactors = FALSE
    )
  }
  df <- do.call(rbind, data_list)

  pd <- ggplot2::position_dodge(width = 0.25)

  # Single panel: each column is one method, showing jitter + RI limits
  p <- ggplot2::ggplot(df) +
    ggplot2::geom_jitter(ggplot2::aes(x = .data$method, y = .data$value),
      width = 0.15, size = 1.2, alpha = 0.3, color = "grey40") +
    ggplot2::geom_linerange(data = limits_df,
      ggplot2::aes(x = .data$method, ymin = .data$lower, ymax = .data$upper,
                   color = .data$method),
      linewidth = 1, position = pd) +
    ggplot2::geom_point(data = limits_df,
      ggplot2::aes(x = .data$method, y = .data$lower, color = .data$method),
      size = 2.5, position = pd) +
    ggplot2::geom_point(data = limits_df,
      ggplot2::aes(x = .data$method, y = .data$upper, color = .data$method),
      size = 2.5, position = pd) +
    ggplot2::geom_errorbar(data = limits_df,
      ggplot2::aes(x = .data$method, ymin = .data$ci_lo_lower,
                   ymax = .data$ci_lo_upper, color = .data$method),
      width = 0.1, linewidth = 0.4, position = pd) +
    ggplot2::geom_errorbar(data = limits_df,
      ggplot2::aes(x = .data$method, ymin = .data$ci_up_lower,
                   ymax = .data$ci_up_upper, color = .data$method),
      width = 0.1, linewidth = 0.4, position = pd) +
    ggplot2::scale_color_manual(
      values = setNames(method_colors[methods], color_labels[methods]),
      labels = color_labels[methods]
    ) +
    ggplot2::labs(x = NULL, y = col_name,
                  title = paste("Reference Interval -", col_name)) +
    ggplot2::theme_bw() +
    ggplot2::theme(
      legend.position   = "none",
      plot.title        = ggplot2::element_text(hjust = 0.5),
      plot.margin       = ggplot2::margin(5.5, 5.5, 5.5, 5.5)
    )

  print(p)
  invisible(p)
}
