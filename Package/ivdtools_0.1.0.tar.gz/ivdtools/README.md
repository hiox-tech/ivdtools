# ivdtools

`ivdtools` provides statistical workflows for in vitro diagnostic (IVD)
method and reagent evaluation. It covers method comparison, ROC analysis,
qualitative agreement, precision, reference intervals, stability, quality
control, curve fitting, outlier and normality assessment, and sample-size
calculations.

## Installation

Install the released package from CRAN after acceptance:

```r
install.packages("ivdtools")
```

For a local source checkout:

```r
install.packages(".", repos = NULL, type = "source")
```

## Quick start

```r
library(ivdtools)

comparison <- data.frame(
  sample_id = 1:12,
  candidate = c(10.1, 11.8, 15.2, 18.9, 21.1, 25.2,
                29.8, 31.9, 35.4, 40.2, 44.8, 49.7),
  reference = c(10, 12, 15, 19, 21, 25, 30, 32, 35, 40, 45, 50)
)

fit <- mcr(comparison, "sample_id", "candidate", "reference")
fit <- correlation(fit)
fit <- regression(fit, method = "deming")
fit <- bland_altman(fit, plot = FALSE)
summary(fit)
```

The analysis functions preserve results inside S3 objects, so a workflow can
be built incrementally and later inspected with `summary()`, `plot()`,
`predict()`, or a module-specific method.

## Main workflows

- Method comparison: `mcr()`, `regression()`, `bland_altman()`, `bias()`
- ROC: `roc()`, `auc()`, `cutoff()`, `mlr()`
- Qualitative agreement: `raw_to_table()`, `diagnostics()`, `kappa()`
- Precision: `precision()`, `variance()`, `ci()`, `profile()`
- Reference intervals: `reference_interval()`
- Stability and QC: `stability_regression()`, `qc_chart()`
- Model fitting: `fit_equation()`, `compare_equation()`
- Supporting tools: `outliers_test()`, `normal_test()`, sample-size functions

See the package vignettes for focused examples. Statistical results should be
interpreted in the context of the applicable study protocol and regulatory or
laboratory requirements.
