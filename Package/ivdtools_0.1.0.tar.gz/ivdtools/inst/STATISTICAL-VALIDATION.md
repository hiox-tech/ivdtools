# Statistical validation record

This file records the software-level evidence used for the 0.1.0 release. It is
not a claim of clinical validation or regulatory approval.

| Area | Independent oracle or invariant |
|---|---|
| Correlation and OLS/WLS | `stats::cor.test()` and `stats::lm()` |
| Deming and Bland-Altman | defining equations and limits-of-agreement formula |
| ROC AUC | Mann–Whitney/rank definition, including tied scores |
| Logistic ROC | `stats::glm(family = binomial())` |
| Qualitative agreement | manually computed confusion metrics, kappa, McNemar |
| Precision | direct `VCA::anovaVCA()` variance components |
| Equation fitting | `stats::lm()`, exact generated nonlinear curves, constraints |
| Reference intervals | type-6 quantiles and mean plus/minus z standard deviations |
| Normality | `stats::shapiro.test()` and `nortest::ad.test()` |
| QC | exact Westgard window and threshold locations |
| Bottle ANOVA/Tukey | `stats::aov()` and `stats::TukeyHSD()` |
| Stability regression | `stats::lm()` on independently aggregated nodes |
| MKT and Arrhenius | direct Boltzmann average and known activation-energy model |
| Sample size | noncentral-t and Wald closed-form equations |

## Defects found by the suite

- ROC trapezoidal integration previously sorted tied false-positive rates only
  by false-positive rate. The cutoff ordering could therefore select the wrong
  vertical-segment endpoint and underestimate AUC; a perfectly separating
  marker could report 0.9 rather than 1.0. Ties are now ordered by
  false-positive rate and sensitivity, and rank-based randomized tests guard
  the result.
- `precision()` previously accepted formulas containing absent design
  variables. The downstream VCA call failed per sample and returned an
  apparently analysed object with warnings. Formula variables are now validated
  at construction and fail immediately with the missing names.

## Known validation boundary

The automated suite verifies implementation behavior on deterministic,
synthetic data and selected edge cases. It does not establish that a statistical
method is appropriate for a particular assay, study design, population,
instrument, or regulatory submission. Numerical results involving iterative
third-party optimizers are checked with explicit tolerances and should also be
revalidated when dependency versions materially change.
