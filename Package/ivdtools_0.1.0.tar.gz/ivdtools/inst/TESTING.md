# Testing ivdtools

The package test suite is designed to answer three different questions:

1. Does the public API load and preserve its documented S3 contracts?
2. Do statistical results agree with independent equations or established
   implementations?
3. Do functions behave predictably for missing, invalid, tied, degenerate, and
   boundary inputs?

Run the complete suite from the package root with:

```r
testthat::test_local(".")
```

For release validation, build the source package first and check the resulting
tarball:

```sh
R CMD build .
R CMD check --as-cran ivdtools_0.1.0.tar.gz
```

## Test organization

- `test-api-contracts.R`: exported names, object fields, registered S3 methods,
  and invisible print/summary returns.
- `test-mcr.R`, `test-roc.R`, `test-qualitative.R`: method comparison,
  diagnostic accuracy, and agreement statistics.
- `test-precision.R`, `test-fit.R`: variance components and curve fitting.
- `test-reference-outliers.R`, `test-qc.R`: reference intervals, distribution
  checks, outlier detection, Westgard rules, and Youden plots.
- `test-stability.R`, `test-sample-size.R`, `test-bottle-anova.R`: stability,
  sample-size, and ANOVA workflows.
- `test-properties.R`: deterministic randomized checks of invariants and
  equivalent input representations.

The suite uses fixed seeds and small deterministic data. Tests should not access
the network, write outside the test temporary directory, or depend on locale,
wall-clock time, or execution order.

## Coverage policy

Line coverage is diagnostic, not the acceptance criterion. Release decisions
prioritize independently checked statistical branches, all exported entry
points, input validation, and S3 dispatch. `covr::package_coverage(type =
"tests")` can be run locally, but expression-level instrumentation of the large
fitting modules may take several minutes.

Real-world method validation remains separate from software verification.
Before clinical or regulatory use, representative instrument data, intended-use
populations, acceptance criteria, and the applicable CLSI or regulatory
protocol must be validated by qualified domain experts.
