## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(ivdtools)

## -----------------------------------------------------------------------------
d <- data.frame(x = 1:6, y = c(2.1, 4.0, 6.1, 8.0, 10.2, 11.9))
fit <- fit_equation("E01", d)
coef(fit)

