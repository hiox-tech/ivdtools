## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(ivdtools)

## -----------------------------------------------------------------------------
d <- data.frame(
  id = 1:12,
  candidate = seq(10, 43, by = 3) + c(0.1, -0.2, 0.2, -0.1),
  reference = seq(10, 43, by = 3)
)
x <- mcr(d, "id", "candidate", "reference")
x <- correlation(x)
x <- regression(x, method = "ols")

