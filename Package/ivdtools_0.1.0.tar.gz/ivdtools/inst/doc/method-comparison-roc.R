## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(ivdtools)

## -----------------------------------------------------------------------------
d <- data.frame(
  id = 1:16,
  new = seq(5, 50, length.out = 16) + rep(c(-0.2, 0.1), 8),
  reference = seq(5, 50, length.out = 16)
)
m <- mcr(d, "id", "new", "reference")
m <- regression(m, method = "deming")
m <- bland_altman(m, plot = FALSE)

