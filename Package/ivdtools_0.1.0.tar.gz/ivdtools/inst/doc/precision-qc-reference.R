## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(ivdtools)

## -----------------------------------------------------------------------------
values <- data.frame(result = seq(80, 120, length.out = 120))
ri <- reference_interval(values, "result", method = "percentile")
ri

