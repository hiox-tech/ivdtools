## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(ivdtools)

## -----------------------------------------------------------------------------
tab <- counts_to_table(tp = 45, fp = 3, tn = 97, fn = 5)
tab <- diagnostics(tab)
tab <- kappa(tab)
tab <- mcnemar(tab)

