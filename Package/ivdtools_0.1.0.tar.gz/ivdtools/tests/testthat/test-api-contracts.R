test_that("all namespace exports are available with expected object kinds", {
  exports <- getNamespaceExports("ivdtools")
  expect_length(exports, 49)

  objects <- mget(exports, envir = asNamespace("ivdtools"), inherits = FALSE)
  data_exports <- grep("^ivd_.*_example$", exports, value = TRUE)
  function_exports <- setdiff(exports, data_exports)

  expect_true(all(vapply(objects[function_exports], is.function, logical(1))))
  expect_true(all(vapply(objects[data_exports], is.data.frame, logical(1))))
})

test_that("documented S3 methods are registered and dispatchable", {
  registered <- c(
    "auc.roc", "bias.mcr", "bland_altman.mcr", "ci.precision",
    "correlation.mcr", "cutoff.roc", "describe.fourfold_table",
    "describe.mcr", "describe.roc", "diagnostics.fourfold_table",
    "kappa.fourfold_table", "mcnemar.fourfold_table", "mlr.roc",
    "normal.precision", "outlier.mcr", "outlier.precision",
    "profile.precision", "regression.mcr", "variance.precision",
    "vc.precision"
  )
  for (method in registered) {
    parts <- strsplit(method, ".", fixed = TRUE)[[1]]
    generic <- parts[1]
    class <- paste(parts[-1], collapse = ".")
    expect_true(
      is.function(getS3method(generic, class, optional = TRUE)),
      info = method
    )
  }
})

test_that("constructors preserve stable S3 object contracts", {
  m <- mcr(ivd_mcr_example, "sid", "test", "ref")
  expect_s3_class(m, "mcr")
  expect_named(
    m,
    c(
      "call", "data", "id", "id_name", "candidate", "reference",
      "candidate_name", "reference_name", "weights", "weights_name", "n",
      "complete_idx", "print", "describe", "correlation", "regression",
      "outlier", "bland_altman", "bias"
    ),
    ignore.order = TRUE
  )

  r <- roc(ivd_roc_example, c("x1", "x2"), "ref")
  expect_s3_class(r, "roc")
  expect_equal(r$n, nrow(ivd_roc_example))
  expect_equal(r$n_pos + r$n_neg, r$n)

  q <- counts_to_table(10, 2, 20, 3)
  expect_s3_class(q, "fourfold_table")
  expect_equal(unname(q$table[3, 3]), 35)
})

test_that("print and summary methods return objects invisibly", {
  m <- mcr(ivd_mcr_example, "sid", "test", "ref")
  capture.output(printed <- withVisible(print(m)))
  expect_false(printed$visible)
  expect_identical(printed$value, m)

  capture.output(summarised <- withVisible(summary(m)))
  expect_false(summarised$visible)
  expect_identical(summarised$value, m)
})

test_that("invalid classes fail through generics", {
  expect_error(correlation(list()), "no applicable method")
  expect_error(auc(list()), "no applicable method")
  expect_error(diagnostics(list()), "no applicable method")
  expect_error(variance(list()), "no applicable method")
})
