test_that("replicate summaries match base calculations and weighting formulas", {
  d <- data.frame(
    x = rep(1:3, each = 3),
    y = c(1, 2, 3, 2, 3, 4, 4, 5, 6)
  )
  observed <- replicate_to_mean(d, "x", "y", weights = "1/sd^2")
  expected_mean <- vapply(split(d$y, d$x), mean, numeric(1))
  expected_sd <- vapply(split(d$y, d$x), stats::sd, numeric(1))

  expect_num_equal(observed$y_mean, expected_mean)
  expect_num_equal(observed$y_sd, expected_sd)
  expect_num_equal(observed$weight, 1 / expected_sd^2)
  expect_equal(observed$y_n, rep(3L, 3))
})

test_that("linear equation fitting agrees with stats::lm", {
  d <- data.frame(x = 1:8, y = c(3.1, 5, 7.2, 8.9, 11.1, 13, 15.2, 16.9))
  observed <- fit_equation("E01", d)
  expected <- stats::lm(y ~ x, data = d)

  expect_s3_class(observed, "fit_equation")
  expect_num_equal(coef(observed), stats::coef(expected), 1e-12)
  expect_num_equal(residuals(observed), stats::residuals(expected), 1e-12)
  expect_num_equal(
    quietly_value(predict(
      observed,
      newdata = data.frame(x = c(2.5, 4.5))
    ))$y,
    stats::predict(expected, data.frame(x = c(2.5, 4.5))),
    1e-12
  )
})

test_that("exact nonlinear data recover known parameters", {
  d <- data.frame(x = 0:6)
  d$y <- 10 * exp(-0.4 * d$x)
  fit <- fit_equation("E04", d, start = list(a = 9, b = 0.3))
  expect_equal(unname(coef(fit)["a"]), 10, tolerance = 1e-6)
  expect_equal(unname(coef(fit)["b"]), 0.4, tolerance = 1e-6)
})

test_that("box and equality constraints are satisfied", {
  d <- data.frame(x = 0:6)
  d$y <- 10 * exp(-0.4 * d$x)

  bounded <- fit_equation(
    "E04", d,
    start = list(a = 8, b = 0.2),
    lower = list(a = 0, b = 0),
    upper = list(a = 20, b = 1)
  )
  expect_true(all(coef(bounded) >= c(a = 0, b = 0)))
  expect_true(all(coef(bounded) <= c(a = 20, b = 1)))

  equal <- fit_equation(
    "E04", d,
    start = list(a = 8, b = 0.4),
    constraints = list(eq = function(p) p["b"] - 0.4)
  )
  expect_equal(unname(coef(equal)["b"]), 0.4, tolerance = 1e-5)
})

test_that("fit comparison ranks an exact generating model first", {
  d <- data.frame(x = 1:10)
  d$y <- 2 + 3 * d$x + c(0.10, -0.05, 0.02, -0.08, 0.04,
                          0.03, -0.06, 0.08, -0.02, -0.06)
  cmp <- compare_equation(d, eqs = c("E01", "E02", "E06"))
  expect_s3_class(cmp, "compare_equation")
  expect_equal(cmp$table$Eq[1], "E01")
  expect_true(all(diff(cmp$table$AIC) >= 0))
})

test_that("fit functions validate columns, methods, and weights", {
  d <- data.frame(x = 1:4, y = 1:4)
  expect_error(replicate_to_mean(d, "missing", "y"), "[Cc]olumn")
  expect_error(fit_equation("unknown", d), "not found|No equation")
  expect_error(fit_equation("E01", d, weights = c(1, -1, 1, 1)), "weight")
})
