# Internal helpers shared by analysis modules.

`%||%` <- function(a, b) {
  if (is.null(a)) b else a
}

.require_pkg <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    stop("Package '", pkg, "' is required but is not installed.", call. = FALSE)
  }
  invisible(TRUE)
}

.format_num <- function(x, digits = 4L) {
  formatC(x, format = "f", digits = digits)
}

.print_df <- function(df) {
  lines <- utils::capture.output(print.data.frame(df, row.names = FALSE))
  if (!length(lines)) {
    return(invisible(df))
  }
  cat(lines[1L], "\n", sep = "")
  cat(strrep("-", nchar(lines[1L])), "\n", sep = "")
  if (length(lines) > 1L) {
    cat(paste(lines[-1L], collapse = "\n"), "\n")
  }
  invisible(df)
}
