#' Sample size and power for Bland-Altman agreement assessment
#'
#' Given the clinical limit \code{delta} and either \code{n} (sample size) or
#' \code{power} (target power), calculates the other using the method of
#' Lu et al. (2016).
#'
#' @param n Sample size (an integer of at least 3). Provide to compute power,
#'        or leave \code{NULL} to compute \code{n} from \code{power}.
#' @param power Target power (in \code{(0, 1)}). Provide to compute
#'        \code{n}, or leave \code{NULL} to compute power from \code{n}.
#' @param mu Mean difference between the two measurement methods.
#' @param sd Standard deviation of the differences. Must be greater than zero.
#' @param delta Clinical agreement limit. Maximum acceptable difference. Must be \code{> 0}.
#' @param conf.level Confidence level for the agreement limit confidence interval (default 0.95).
#' @param agree.level Agreement level for the limits of agreement (default 0.95).
#' @param n.min Minimum sample size when searching for \code{n} (only used when computing \code{n}). Default \code{3}.
#' @param n.max Maximum sample size when searching for \code{n} (only used when computing \code{n}). Default \code{1e5}.
#'
#' @return An object of class \code{sample_size_bland_altman}: a numeric power
#'   value when \code{n} is supplied, or an integer sample size when
#'   \code{power} is supplied. Analysis inputs are retained as attributes.
#'
#' @references
#' Lu MJ, Zhong WH, Liu YX, Miao HZ, Li YC, Ji MH (2016)
#' Sample size for assessing agreement between two methods of measurement
#' by Bland-Altman method. *International Journal of Biostatistics*, 12(2).
#' \doi{10.1515/ijb-2015-0039}
#'
#' @examples
#' # Mode 1: compute power given sample size
#' sample_size_bland_altman(n = 203, mu = 0.2, sd = 1, delta = 2.5)
#'
#' # Mode 2: compute sample size given target power
#' sample_size_bland_altman(power = 0.80, mu = 0.2, sd = 1, delta = 2.5)
#'
#' @export
sample_size_bland_altman <- function(
    n = NULL,
    power = NULL,
    mu,
    sd,
    delta,
    conf.level = 0.95,
    agree.level = 0.95,
    n.min = 3L,
    n.max = 1e5) {

  # Input validation
  given_n <- !is.null(n)
  given_p <- !is.null(power)
  n_given <- sum(given_n, given_p)

  if (n_given != 1L)
    stop("Exactly one of {n, power} must be provided.")

  if (!is.numeric(mu) || length(mu) != 1L || !is.finite(mu))
    stop("'mu' must be a single finite numeric value, got ", deparse(mu))
  if (!is.numeric(sd) || length(sd) != 1L || !is.finite(sd) || sd <= 0)
    stop("'sd' must be a single finite positive value, got ", deparse(sd))
  if (!is.numeric(delta) || length(delta) != 1L || !is.finite(delta) || delta <= 0)
    stop("'delta' must be a single finite positive value, got ", deparse(delta))
  if (!is.numeric(conf.level) || length(conf.level) != 1L ||
      !is.finite(conf.level) || conf.level <= 0 || conf.level >= 1)
    stop("'conf.level' must be a single finite value in (0, 1), got ", conf.level)
  if (!is.numeric(agree.level) || length(agree.level) != 1L ||
      !is.finite(agree.level) || agree.level <= 0 || agree.level >= 1)
    stop("'agree.level' must be a single finite value in (0, 1), got ", agree.level)

  if (given_n) {
    mode <- "solve_p"
    if (!is.numeric(n) || length(n) != 1L || !is.finite(n) ||
        n < 3L || n != floor(n))
      stop("'n' must be a single integer >= 3, got ", n)
  } else {
    mode <- "solve_n"
    if (!is.numeric(power) || length(power) != 1L || !is.finite(power) ||
        power <= 0 || power >= 1)
      stop("'power' must be a single finite value in (0, 1), got ", power)
    if (!is.numeric(n.min) || length(n.min) != 1L || !is.finite(n.min) ||
        n.min < 3L || n.min != floor(n.min))
      stop("'n.min' must be a single integer >= 3, got ", n.min)
    if (!is.numeric(n.max) || length(n.max) != 1L || !is.finite(n.max) ||
        n.max < n.min || n.max != floor(n.max))
      stop("'n.max' must be a single integer > n.min, got ", n.max)
  }

  # Power calculator (given n)
  power_at <- function(n_val) {
    z_gamma <- qnorm(1 - (1 - agree.level) / 2)
    df      <- n_val - 1
    t_crit  <- qt(1 - (1 - conf.level) / 2, df)
    SE      <- sd * sqrt(1 / n_val + z_gamma^2 / (2 * (n_val - 1)))
    tau1    <- (delta - mu - z_gamma * sd) / SE
    tau2    <- (delta + mu - z_gamma * sd) / SE
    pwr     <- pt(t_crit, df, ncp = tau1, lower.tail = FALSE) +
               pt(-t_crit, df, ncp = tau2, lower.tail = TRUE)
    min(max(pwr, 0), 1)
  }

  # Build result object
  make_result <- function(n_val, pwr, note = NULL, typ) {
    if (typ == "solve_p") {
      res <- structure(pwr, class = "sample_size_bland_altman",
        n           = n_val,
        mu          = mu,
        sd          = sd,
        delta       = delta,
        conf.level  = conf.level,
        agree.level = agree.level,
        type        = typ)
    } else {
      res <- structure(as.integer(n_val), class = "sample_size_bland_altman",
        power       = pwr,
        mu          = mu,
        sd          = sd,
        delta       = delta,
        conf.level  = conf.level,
        agree.level = agree.level,
        type        = typ)
    }
    if (!is.null(note)) attr(res, "note") <- note
    res
  }

  # Return result (relies on S3 auto-printing)
  if (mode == "solve_p")
    return(make_result(n, power_at(n), typ = "solve_p"))

  # Mode B: compute sample size (given power)
  # Check lower bound
  p_min <- power_at(n.min)
  if (p_min >= power) {
    return(make_result(n.min, p_min, typ = "solve_n"))
  }

  # Check upper bound (n.max is a hard limit)
  p_hi <- power_at(n.max)
  note <- NULL
  if (p_hi < power) {
    note <- sprintf(paste(
      "Cannot reach target power = %.2f at n.max = %d.",
      "Try a larger n.max or a wider clinical limit."
    ), power, n.max)
    warning(note)
    return(make_result(n.max, p_hi, note = note, typ = "solve_n"))
  }

  # Binary search
  lo <- n.min
  hi <- n.max
  while (hi - lo > 1L) {
    mid   <- (lo + hi) %/% 2L
    p_mid <- power_at(mid)
    if (p_mid >= power) hi <- mid else lo <- mid
  }

  make_result(hi, power_at(hi), typ = "solve_n")
}

# S3 print method

#' @export
print.sample_size_bland_altman <- function(x, ...) {
  type_label <- switch(attr(x, "type"),
    solve_n = "Compute n from power",
    solve_p = "Compute power from n",
    "Bland-Altman agreement"
  )

  typ <- attr(x, "type")
  if (typ == "solve_n") {
    n_val <- as.integer(x)
    pwr   <- attr(x, "power")
  } else {
    n_val <- attr(x, "n")
    pwr   <- as.numeric(x)
  }

  cat("Sample size for Bland-Altman agreement assessment\n")
  cat(sprintf("  Mode             : %s\n",   type_label))
  cat(sprintf("  Mean difference  : %.4f\n", attr(x, "mu")))
  cat(sprintf("  SD of differences: %.4f\n", attr(x, "sd")))
  cat(sprintf("  Clinical limit   : %.4f\n", attr(x, "delta")))
  cat(sprintf("  Confidence level : %.4f\n", attr(x, "conf.level")))
  cat(sprintf("  Agreement level  : %.4f\n", attr(x, "agree.level")))
  cat(sprintf("  Sample size (n)  : %d\n",   n_val))
  cat(sprintf("  Power            : %.6f\n", pwr))
  note <- attr(x, "note")
  if (!is.null(note))
    cat(sprintf("  Note: %s\n", note))
  invisible(x)
}

#' Sample size or half-width for a single proportion confidence interval
#'
#' Given a target proportion \code{p} and either \code{d} (half-width) or
#' \code{n} (sample size), compute the unknown quantity using one of seven
#' confidence interval methods.
#'
#' @param p Expected proportion. Must lie in (0, 1). **Required** -- no default.
#' @param d Desired half-width (margin of error). Provide this to compute
#'        \code{n}, or leave \code{NULL} to compute \code{d} from \code{n}.
#' @param n Sample size (integer). Provide this to compute \code{d},
#'        or leave \code{NULL} to compute \code{n} from \code{d}.
#' @param conf.level Confidence level. Default 0.95.
#' @param method Confidence interval method. One of:
#'   \code{"wald"}, \code{"wald-cc"}, \code{"wilson"}, \code{"wilson-cc"},
#'   \code{"agresti-coull"}, \code{"jeffreys"}, \code{"clopper-pearson"}.
#' @param n.max Maximum sample size to search (only used when solving for
#'        \code{n}). Default 1e6.
#' @param tol Convergence tolerance. Default 1e-6.
#' @return An object of class \code{sample_size_proportion_ci}.
#'   \itemize{
#'     \item If \code{d} is given: returns an integer sample size \code{n}
#'           with metadata stored in attributes (\code{method}, \code{p},
#'           \code{d}, \code{conf.level}, \code{type}).
#'     \item If \code{n} is given: returns a numeric half-width \code{d}
#'           with metadata stored in attributes (\code{method}, \code{p},
#'           \code{n}, \code{conf.level}, \code{type}).
#'   }
#'   Use \code{\link{print}} to see full context.
#'
#' @examples
#' # Mode 1: compute n (given p and d)
#' sample_size_proportion_ci(p = 0.3, d = 0.05)
#'
#' # Mode 2: compute d (given p and n)
#' sample_size_proportion_ci(p = 0.3, n = 320, conf.level = 0.99)
#'
#' @export
sample_size_proportion_ci <- function(
    p,
    n = NULL,
    d = NULL,
    conf.level = 0.95,
    method = c("wilson", "wald", "wald-cc", "agresti-coull",
               "jeffreys", "wilson-cc", "clopper-pearson"),
    n.max = 1e6,
    tol = 1e-6) {

  method <- match.arg(method)

  # Input validation
  if (missing(p))
    stop("'p' must be provided (no default).")
  if (!is.numeric(p) || length(p) != 1L || !is.finite(p) || p <= 0 || p >= 1)
    stop("'p' must be a single finite value in (0, 1).")
  if (!is.numeric(conf.level) || length(conf.level) != 1L ||
      !is.finite(conf.level) || conf.level <= 0 || conf.level >= 1)
    stop("'conf.level' must be a single finite value in (0, 1), got ", conf.level)
  if (!is.numeric(n.max) || length(n.max) != 1L ||
      !is.finite(n.max) || n.max < 2L || n.max != floor(n.max))
    stop("'n.max' must be a single integer >= 2, got ", n.max)

  given_n <- !is.null(n)
  given_d <- !is.null(d)
  n_given <- sum(given_n, given_d)

  if (n_given != 1L)
    stop("Exactly one of {n, d} must be provided (along with p).")

  if (given_n) {
    mode <- "solve_d"
    if (!is.numeric(n) || length(n) != 1L || !is.finite(n) ||
        n < 2L || n != floor(n))
      stop("'n' must be a single integer >= 2, got ", n)
  } else {
    mode <- "solve_n"
    if (!is.numeric(d) || length(d) != 1L || !is.finite(d) || d <= 0 || d > 0.5)
      stop("'d' must be a single finite value in (0, 0.5], got ", d)
  }

  # Generic half-width calculator — works for any conf.level
  hw_at <- function(n_val, cl_val) {
    a <- 1 - cl_val
    z <- qnorm(1 - a / 2)

    switch(method,
      wald = {
        z * sqrt(p * (1 - p) / n_val)
      },
      `wald-cc` = {
        z * sqrt(p * (1 - p) / n_val) + 1 / (2 * n_val)
      },
      wilson = {
        denom <- 1 + z^2 / n_val
        (z / denom) * sqrt(p * (1 - p) / n_val + z^2 / (4 * n_val^2))
      },
      `wilson-cc` = {
        denom <- 1 + z^2 / n_val
        (z / denom) * sqrt(p * (1 - p) / n_val + z^2 / (4 * n_val^2)) +
          1 / (2 * n_val)
      },
      `agresti-coull` = {
        x_val   <- round(n_val * p)
        n_tilde <- n_val + z^2
        p_tilde <- (x_val + z^2 / 2) / n_tilde
        z * sqrt(p_tilde * (1 - p_tilde) / n_tilde)
      },
      jeffreys = {
        x_val <- round(n_val * p)
        if (x_val == 0L) {
          upper <- qbeta(1 - a / 2, 0.5, n_val + 0.5)
          return(upper - p)
        }
        if (x_val == n_val) {
          lower <- qbeta(a / 2, n_val + 0.5, 0.5)
          return(p - lower)
        }
        lower <- qbeta(a / 2,     x_val + 0.5, n_val - x_val + 0.5)
        upper <- qbeta(1 - a / 2, x_val + 0.5, n_val - x_val + 0.5)
        max(p - lower, upper - p)
      },
      `clopper-pearson` = {
        x_val <- round(n_val * p)
        if (x_val == 0L) {
          upper <- qbeta(1 - a / 2, 1, n_val)
          return(upper - p)
        }
        if (x_val == n_val) {
          lower <- qbeta(a / 2, n_val, 1)
          return(p - lower)
        }
        lower <- qbeta(a / 2,     x_val,     n_val - x_val + 1)
        upper <- qbeta(1 - a / 2, x_val + 1, n_val - x_val)
        max(p - lower, upper - p)
      }
    )
  }

  # Build result
  make_result <- function(n_val, d_val, note = NULL, typ) {
    if (typ == "solve_n") {
      structure(as.integer(n_val), class = "sample_size_proportion_ci",
        method     = method,
        p          = p,
        d          = d_val,
        conf.level = conf.level,
        type       = typ,
        note       = note)
    } else {
      structure(d_val, class = "sample_size_proportion_ci",
        n          = n_val,
        method     = method,
        p          = p,
        conf.level = conf.level,
        type       = typ,
        note       = note)
    }
  }

  # Dispatch
  # Mode A: solve for n (given p and d)
  if (mode == "solve_n") {

    # Wald: closed-form solution
    if (method == "wald") {
      alpha <- 1 - conf.level
      z_val <- qnorm(1 - alpha / 2)
      n_val <- max(2L, ceiling(z_val^2 * p * (1 - p) / d^2))

      return(make_result(n_val, d, typ = "solve_n"))
    }

    # Other methods: exponential search + binary search
    if (hw_at(n.max, conf.level) > d + tol) {
      note <- sprintf(
        "Method '%s' cannot reach half-width d = %.4f at n.max = %d (p = %.4f)",
        method, d, n.max, p
      )
      warning(note)
      return(make_result(n.max, d, note = note, typ = "solve_n"))
    }
    if (hw_at(2.0, conf.level) <= d + tol) {
      return(make_result(2L, d, typ = "solve_n"))
    }

    # Exponential search
    n_cur <- 2L
    while (hw_at(as.numeric(n_cur), conf.level) > d + tol && n_cur < n.max)
      n_cur <- min(n_cur * 2L, n.max)

    hi <- n_cur
    lo <- max(2L, n_cur %/% 2L)

    while (lo < hi) {
      mid    <- lo + (hi - lo) %/% 2L
      hw_mid <- hw_at(as.numeric(mid), conf.level)
      if (hw_mid <= d + tol) hi <- mid else lo <- mid + 1L
    }

    # Backtrack: for agresti-coull / jeffreys / clopper-pearson,
    # round(n * p) makes the half-width non-monotonic, so the binary
    # search minimum may not be the global minimum.
    # Scan lo-1 … max(2, lo - L), where L is a sufficiently large range.
    # The period of round(n*p) jumps is roughly 1/min(p, 1-p); use
    # 3× that period or lo/2, whichever is larger.
    lo_best <- lo
    period_est <- max(3L, as.integer(1 / min(p, 1 - p, 0.5)) * 3L)
    n_scan_end <- max(2L, lo - max(period_est, lo %/% 2L, 200L))
    for (n_try in (lo - 1L):n_scan_end) {
      if (hw_at(as.numeric(n_try), conf.level) <= d + tol) {
        lo_best <- n_try
      }
    }

    return(make_result(lo_best, d, typ = "solve_n"))
  }

  # Mode B: solve for d (given p and n)
  # mode == "solve_d"
  hw_val <- hw_at(as.numeric(n), conf.level)

  make_result(n, hw_val, typ = "solve_d")
}

# S3 print method

#' @export
print.sample_size_proportion_ci <- function(x, ...) {
  type_label <- switch(attr(x, "type"),
    solve_n = "Compute n from p and d",
    solve_d = "Compute d from p and n",
    "Single proportion confidence interval"
  )

  typ <- attr(x, "type")
  if (typ == "solve_n") {
    n_show <- as.integer(x)
    d_show <- attr(x, "d")
  } else {
    n_show <- attr(x, "n")
    d_show <- as.numeric(x)
  }

  cat("Single proportion confidence interval\n")
  cat(sprintf("  Mode             : %s\n", type_label))
  cat(sprintf("  Method           : %s\n", attr(x, "method")))
  cat(sprintf("  Target proportion: %.4f\n", attr(x, "p")))
  cat(sprintf("  Confidence level : %.4f\n", attr(x, "conf.level")))
  cat(sprintf("  Sample size (n)  : %d\n", n_show))
  cat(sprintf("  Half-width (d)   : %.6f\n", d_show))
  note <- attr(x, "note")
  if (!is.null(note))
    cat(sprintf("  Note: %s\n", note))
  invisible(x)
}

#' Single-arm target value test -- sample size / significance level / power
#'
#' Given any **two** of \code{\{n, alpha, power\}}, compute the third using a
#' confidence-interval inversion approach for a one-sample proportion test
#' against a known target value \code{p0}.
#'
#' @param p0 Target (null hypothesis) proportion. Must be in (0, 1).
#' @param p1 Expected (alternative hypothesis) proportion. Must be in (0, 1).
#' @param n Sample size (integer). Leave \code{NULL} to compute it.
#' @param alpha Significance level (Type I error). Leave \code{NULL} to compute it.
#' @param power Desired test power (1 - Type II error). Leave \code{NULL} to compute it.
#' @param alternative Direction of the alternative hypothesis.
#'   One of \code{"greater"}, \code{"less"}, or \code{"two.sided"}.
#' @param method Confidence interval method for test inversion.
#'   One of \code{"wald"}, \code{"wald-cc"}, \code{"wilson"},
#'   \code{"wilson-cc"}, \code{"agresti-coull"}, \code{"jeffreys"},
#'   or \code{"clopper-pearson"}.
#' @param n.max Maximum sample size (only used when computing \code{n}).
#' @param tol Tolerance passed to \code{\link{uniroot}} when solving \code{alpha}. Default 1e-8.
#' @return An object of class \code{sample_size_proportion}.
#'   \itemize{
#'     \item If computing \code{n}: returns an integer sample size.
#'     \item If computing \code{power}: returns a numeric power in \code{[0, 1]}.
#'     \item If computing \code{alpha}: returns a numeric significance level in \code{(0, 1)}.
#'   }
#'   Metadata is stored in attributes (\code{method}, \code{p0}, \code{p1}, \code{alpha},
#'   \code{power}, \code{x_crit}, \code{alternative}, \code{type}).
#'   Use \code{\link{print}} for full context.
#'
#' @examples
#' # Mode 1 -- compute n (given alpha and power)
#' sample_size_proportion(p0 = 0.2, p1 = 0.35,
#'                        alpha = 0.025, power = 0.8, method = "wilson")
#'
#' # Mode 2 -- compute power (given n and alpha)
#' sample_size_proportion(p0 = 0.2, p1 = 0.35,
#'                        n = 60, alpha = 0.025, method = "wald-cc")
#'
#' # Mode 3 -- compute alpha (given n and power)
#' sample_size_proportion(p0 = 0.2, p1 = 0.35,
#'                        n = 60, power = 0.8, method = "clopper-pearson")
#'
#' @export
sample_size_proportion <- function(
    p0 = 0.2,
    p1 = 0.35,
    n = NULL,
    alpha = NULL,
    power = NULL,
    alternative = c("greater", "less", "two.sided"),
    method = c("wilson", "wald", "wald-cc", "agresti-coull",
               "jeffreys", "wilson-cc", "clopper-pearson"),
    n.max = 1e6,
    tol = 1e-8) {

  alternative <- match.arg(alternative)
  method      <- match.arg(method)

  # Input validation
  if (!is.numeric(p0) || length(p0) != 1L || !is.finite(p0) || p0 <= 0 || p0 >= 1)
    stop("'p0' must be a single finite value in (0, 1), got ", p0)
  if (!is.numeric(p1) || length(p1) != 1L || !is.finite(p1) || p1 <= 0 || p1 >= 1)
    stop("'p1' must be a single finite value in (0, 1), got ", p1)
  if (!is.numeric(n.max) || length(n.max) != 1L ||
      !is.finite(n.max) || n.max < 2L || n.max != floor(n.max))
    stop("'n.max' must be a single integer >= 2, got ", n.max)

  given_n <- !is.null(n)
  given_a <- !is.null(alpha)
  given_p <- !is.null(power)
  n_given <- sum(given_n, given_a, given_p)

  if (n_given < 2L)
    stop("At least two of {n, alpha, power} must be supplied.")
  if (n_given == 3L) {
    mode <- "check"
    n_check <- n; alpha_check <- alpha; power_check <- power
  } else if (!given_n) {
    mode <- "solve_n"
  } else if (!given_a) {
    mode <- "solve_a"
    if (!is.numeric(n) || length(n) != 1L || !is.finite(n) ||
        n < 2L || n != floor(n))
      stop("'n' must be a single integer >= 2, got ", n)
  } else {
    mode <- "solve_p"
    if (!is.numeric(n) || length(n) != 1L || !is.finite(n) ||
        n < 2L || n != floor(n))
      stop("'n' must be a single integer >= 2, got ", n)
  }

  # Direction check — only for solve_n, solve_a, and solve_p modes
  if (mode != "check") {
    if (alternative == "greater" && p1 <= p0)
      stop("For alternative = 'greater', p1 must be > p0.")
    if (alternative == "less" && p1 >= p0)
      stop("For alternative = 'less', p1 must be < p0.")
    if (alternative == "two.sided" && p1 == p0)
      stop("For alternative = 'two.sided', p1 must differ from p0.")
  }

  # Critical value helper functions (one-sided, parameterised by alpha)
  # Minimum x such that the one-sided lower bound > p0 (for "greater")
  find_x_greater <- function(n_val, a_val) {
    z_a <- qnorm(1 - a_val)

    lb <- switch(method,
      wald = function(k) {
        p_h <- k / n_val
        p_h - z_a * sqrt(p_h * (1 - p_h) / n_val)
      },
      `wald-cc` = function(k) {
        p_h <- k / n_val
        p_h - z_a * sqrt(p_h * (1 - p_h) / n_val) - 1 / (2 * n_val)
      },
      wilson = function(k) {
        p_h   <- k / n_val
        denom <- 1 + z_a^2 / n_val
        (p_h + z_a^2 / (2 * n_val) -
           z_a * sqrt(p_h * (1 - p_h) / n_val + z_a^2 / (4 * n_val^2))) / denom
      },
      `wilson-cc` = function(k) {
        p_h   <- k / n_val
        denom <- 1 + z_a^2 / n_val
        (p_h + z_a^2 / (2 * n_val) -
           z_a * sqrt(p_h * (1 - p_h) / n_val + z_a^2 / (4 * n_val^2))) / denom -
          1 / (2 * n_val)
      },
      `agresti-coull` = function(k) {
        n_t <- n_val + z_a^2
        p_t <- (k + z_a^2 / 2) / n_t
        p_t - z_a * sqrt(p_t * (1 - p_t) / n_t)
      },
      jeffreys = function(k) {
        qbeta(a_val, k + 0.5, n_val - k + 0.5)
      },
      `clopper-pearson` = function(k) {
        qbeta(a_val, k, n_val - k + 1)
      }
    )

    if (lb(n_val) <= p0) return(n_val + 1L)
    if (lb(0L) > p0)     return(0L)

    lo <- 0L
    hi <- n_val
    while (lo < hi) {
      mid <- (lo + hi) %/% 2L
      if (lb(mid) > p0) hi <- mid else lo <- mid + 1L
    }
    lo
  }

  # Maximum x such that the one-sided upper bound < p0 (for "less")
  find_x_less <- function(n_val, a_val) {
    z_a <- qnorm(1 - a_val)

    ub <- switch(method,
      wald = function(k) {
        p_h <- k / n_val
        p_h + z_a * sqrt(p_h * (1 - p_h) / n_val)
      },
      `wald-cc` = function(k) {
        p_h <- k / n_val
        p_h + z_a * sqrt(p_h * (1 - p_h) / n_val) + 1 / (2 * n_val)
      },
      wilson = function(k) {
        p_h   <- k / n_val
        denom <- 1 + z_a^2 / n_val
        (p_h + z_a^2 / (2 * n_val) +
           z_a * sqrt(p_h * (1 - p_h) / n_val + z_a^2 / (4 * n_val^2))) / denom
      },
      `wilson-cc` = function(k) {
        p_h   <- k / n_val
        denom <- 1 + z_a^2 / n_val
        (p_h + z_a^2 / (2 * n_val) +
           z_a * sqrt(p_h * (1 - p_h) / n_val + z_a^2 / (4 * n_val^2))) / denom +
          1 / (2 * n_val)
      },
      `agresti-coull` = function(k) {
        n_t <- n_val + z_a^2
        p_t <- (k + z_a^2 / 2) / n_t
        p_t + z_a * sqrt(p_t * (1 - p_t) / n_t)
      },
      jeffreys = function(k) {
        qbeta(1 - a_val, k + 0.5, n_val - k + 0.5)
      },
      `clopper-pearson` = function(k) {
        qbeta(1 - a_val, k + 1, n_val - k)
      }
    )

    if (ub(0L) >= p0) return(-1L)
    if (ub(n_val) < p0) return(n_val)

    lo <- 0L
    hi <- n_val
    while (lo < hi) {
      mid <- (lo + hi + 1L) %/% 2L
      if (ub(mid) < p0) lo <- mid else hi <- mid - 1L
    }
    lo
  }

  # Power calculator (parameterised by alpha)
  calc_power <- function(n_val, a_val) {
    if (alternative == "greater") {
      x_c <- find_x_greater(n_val, a_val)
      if (x_c > n_val) return(0)
      1 - pbinom(x_c - 1L, n_val, p1)
    } else if (alternative == "less") {
      x_c <- find_x_less(n_val, a_val)
      if (x_c < 0L) return(0)
      pbinom(x_c, n_val, p1)
    } else {
      x_l  <- find_x_less(n_val, a_val / 2)
      x_u  <- find_x_greater(n_val, a_val / 2)
      p_lo <- if (x_l >= 0L) pbinom(x_l, n_val, p1) else 0
      p_hi <- if (x_u <= n_val) 1 - pbinom(x_u - 1L, n_val, p1) else 0
      min(p_lo + p_hi, 1)
    }
  }

  # Construct result
  make_result <- function(n_val, a_val, p_val, x_c, typ, note = NULL) {
    scalars <- list(solve_n = n_val, solve_p = p_val, solve_a = a_val, check = a_val)
    result  <- scalars[[typ]]
    if (typ == "solve_n") result <- as.integer(result)
    structure(result, class = "sample_size_proportion",
      n           = n_val,
      method      = method,
      p0          = p0,
      p1          = p1,
      alpha       = a_val,
      power       = p_val,
      x_crit      = x_c,
      alternative = alternative,
      type        = typ,
      note        = note)
  }

  # Dispatch
  # Mode A: compute n (given alpha and power)
  if (mode == "solve_n") {
    if (!is.numeric(alpha) || length(alpha) != 1L || !is.finite(alpha) ||
        alpha <= 0 || alpha >= 1)
      stop("'alpha' must be a single finite value in (0, 1), got ", alpha)
    if (!is.numeric(power) || length(power) != 1L || !is.finite(power) ||
        power <= 0 || power >= 1)
      stop("'power' must be a single finite value in (0, 1), got ", power)

    z_alpha <- qnorm(if (alternative == "two.sided") 1 - alpha / 2
                     else 1 - alpha)
    z_beta  <- qnorm(power)

    n_start <- ceiling(
      (z_alpha * sqrt(p0 * (1 - p0)) + z_beta * sqrt(p1 * (1 - p1)))^2 /
        (p1 - p0)^2
    )
    n_start <- max(2L, n_start - 5L)

    n_cur <- n_start
    while (n_cur <= n.max) {
      p_ach <- calc_power(n_cur, alpha)
      if (p_ach >= power) {
        xc <- if (alternative == "greater") find_x_greater(n_cur, alpha)
              else if (alternative == "less") find_x_less(n_cur, alpha)
              else c(lower = find_x_less(n_cur, alpha / 2),
                     upper = find_x_greater(n_cur, alpha / 2))

        # Backtrack: find the true minimum n that satisfies
        n_best <- n_cur
        n_min <- max(2L, n_cur %/% 2L)
        for (n_back in (n_cur - 1L):n_min) {
          if (calc_power(n_back, alpha) >= power) {
            n_best <- n_back
          }
        }
        if (n_best != n_cur) {
          xc <- if (alternative == "greater") find_x_greater(n_best, alpha)
                else if (alternative == "less") find_x_less(n_best, alpha)
                else c(lower = find_x_less(n_best, alpha / 2),
                       upper = find_x_greater(n_best, alpha / 2))
        }
        return(make_result(n_best, alpha,
                           calc_power(n_best, alpha), xc, "solve_n"))
      }
      n_cur <- n_cur + 1L
    }

    note <- sprintf(
      "Method '%s' cannot reach target power = %.2f at n.max = %d (p0 = %.4f, p1 = %.4f)",
      method, power, n.max, p0, p1
    )
    warning(note)
    return(make_result(n.max, alpha, calc_power(n.max, alpha), NULL,
                       "solve_n", note = note))
  }

  # Mode B: compute power (given n and alpha)
  if (mode == "solve_p") {
    if (!is.numeric(alpha) || length(alpha) != 1L || !is.finite(alpha) ||
        alpha <= 0 || alpha >= 1)
      stop("'alpha' must be a single finite value in (0, 1), got ", alpha)
    p_ach <- calc_power(n, alpha)
    xc <- if (alternative == "greater") find_x_greater(n, alpha)
          else if (alternative == "less") find_x_less(n, alpha)
          else c(lower = find_x_less(n, alpha / 2),
                 upper = find_x_greater(n, alpha / 2))
    return(make_result(n, alpha, p_ach, xc, "solve_p"))
  }

  # Boundary alpha helpers — given x_crit, find alpha such that
  #   CI_lower(x_crit) = p0 ("greater") or
  #   CI_upper(x_crit) = p0 ("less")
  # Alpha at which the one-sided lower bound at x equals p0 ("greater")
  boundary_alpha_greater <- function(x_val, n_val) {
    switch(method,
      wald = {
        # z * sqrt(x(n-x)/n³) = x/n - p0
        if (x_val == 0L || x_val == n_val) return(0.5)
        z_h <- (x_val / n_val - p0) * sqrt(n_val^3 / (x_val * (n_val - x_val)))
        if (z_h <= 0) return(0.5)
        1 - pnorm(z_h)
      },
      `wald-cc` = {
        if (x_val == 0L || x_val == n_val) return(0.5)
        z_h <- (x_val / n_val - p0 - 1 / (2 * n_val)) *
          sqrt(n_val^3 / (x_val * (n_val - x_val)))
        if (z_h <= 0) return(0.5)
        1 - pnorm(z_h)
      },
      wilson = {
        if (x_val == 0L || x_val == n_val) return(0.5)

        # Solve CI_lower(x) = p0 via uniroot (monotonic function)
        f_z <- function(z_val) {
          denom <- 1 + z_val^2 / n_val
          (x_val / n_val + z_val^2 / (2 * n_val) -
             z_val * sqrt((x_val / n_val) * (1 - x_val / n_val) / n_val +
                          z_val^2 / (4 * n_val^2))) / denom - p0
        }
        tryCatch(
          uniroot(f_z, c(1e-10, 8), tol = tol)$root |> {\(z) 1 - pnorm(z)}(),
          error = function(e) 0.5
        )
      },
      `wilson-cc` = {
        if (x_val == 0L || x_val == n_val) return(0.5)
        f_z <- function(z_val) {
          denom <- 1 + z_val^2 / n_val
          (x_val / n_val + z_val^2 / (2 * n_val) -
             z_val * sqrt((x_val / n_val) * (1 - x_val / n_val) / n_val +
                          z_val^2 / (4 * n_val^2))) / denom -
            1 / (2 * n_val) - p0
        }
        tryCatch(
          uniroot(f_z, c(1e-10, 8), tol = tol)$root |> {\(z) 1 - pnorm(z)}(),
          error = function(e) 0.5
        )
      },
      `agresti-coull` = {
        if (x_val == 0L || x_val == n_val) return(0.5)

        # n_tilde = n + z², p_tilde = (x + z²/2) / n_tilde; implicitly solve for z
        f_z <- function(z_val) {
          n_t <- n_val + z_val^2
          p_t <- (x_val + z_val^2 / 2) / n_t
          p_t - z_val * sqrt(p_t * (1 - p_t) / n_t) - p0
        }
        tryCatch(
          uniroot(f_z, c(1e-10, 8), tol = tol)$root |> {\(z) 1 - pnorm(z)}(),
          error = function(e) 0.5
        )
      },
      jeffreys = {
        pbeta(p0, x_val + 0.5, n_val - x_val + 0.5)
      },
      `clopper-pearson` = {
        if (x_val == 0L) return(1)
        if (x_val == n_val) return(0)
        pbeta(p0, x_val, n_val - x_val + 1)
      }
    )
  }

  # Alpha at which the one-sided upper bound at x equals p0 ("less")
  boundary_alpha_less <- function(x_val, n_val) {
    switch(method,
      wald = {
        if (x_val == 0L || x_val == n_val) return(0.5)
        z_h <- (p0 - x_val / n_val) * sqrt(n_val^3 / (x_val * (n_val - x_val)))
        if (z_h <= 0) return(0.5)
        1 - pnorm(z_h)
      },
      `wald-cc` = {
        if (x_val == 0L || x_val == n_val) return(0.5)
        z_h <- (p0 - x_val / n_val - 1 / (2 * n_val)) *
          sqrt(n_val^3 / (x_val * (n_val - x_val)))
        if (z_h <= 0) return(0.5)
        1 - pnorm(z_h)
      },
      wilson = {
        if (x_val == 0L || x_val == n_val) return(0.5)
        f_z <- function(z_val) {
          denom <- 1 + z_val^2 / n_val
          (x_val / n_val + z_val^2 / (2 * n_val) +
             z_val * sqrt((x_val / n_val) * (1 - x_val / n_val) / n_val +
                          z_val^2 / (4 * n_val^2))) / denom - p0
        }
        tryCatch(
          uniroot(f_z, c(1e-10, 8), tol = tol)$root |> {\(z) 1 - pnorm(z)}(),
          error = function(e) 0.5
        )
      },
      `wilson-cc` = {
        if (x_val == 0L || x_val == n_val) return(0.5)
        f_z <- function(z_val) {
          denom <- 1 + z_val^2 / n_val
          (x_val / n_val + z_val^2 / (2 * n_val) +
             z_val * sqrt((x_val / n_val) * (1 - x_val / n_val) / n_val +
                          z_val^2 / (4 * n_val^2))) / denom +
            1 / (2 * n_val) - p0
        }
        tryCatch(
          uniroot(f_z, c(1e-10, 8), tol = tol)$root |> {\(z) 1 - pnorm(z)}(),
          error = function(e) 0.5
        )
      },
      `agresti-coull` = {
        if (x_val == 0L || x_val == n_val) return(0.5)
        f_z <- function(z_val) {
          n_t <- n_val + z_val^2
          p_t <- (x_val + z_val^2 / 2) / n_t
          p_t + z_val * sqrt(p_t * (1 - p_t) / n_t) - p0
        }
        tryCatch(
          uniroot(f_z, c(1e-10, 8), tol = tol)$root |> {\(z) 1 - pnorm(z)}(),
          error = function(e) 0.5
        )
      },
      jeffreys = {
        1 - pbeta(p0, x_val + 0.5, n_val - x_val + 0.5)
      },
      `clopper-pearson` = {
        if (x_val == n_val) return(1)
        if (x_val == 0L) return(0)
        1 - pbeta(p0, x_val + 1, n_val - x_val)
      }
    )
  }

  # Mode C: compute alpha (given n and power)
  # Instead of solving the stepwise power function directly, we:
  #   (1) Determine the critical x that achieves the target power, then
  #   (2) Compute the boundary alpha at which the CI at x just excludes p0.
  # This yields a unique and well-defined answer.
  # + When all three parameters are supplied, enters "check" mode.
  target_power <- if (mode == "solve_a") power else power_check
  note <- NULL

  if (alternative == "greater") {
    x_search_start <- max(floor(n * p0) + 1L, qbinom(1 - target_power, n, p1,
                                     lower.tail = TRUE))
    x_found <- NULL
    for (x_candidate in x_search_start:n) {
      pwr <- 1 - pbinom(x_candidate - 1L, n, p1)
      if (pwr >= target_power - 1e-12) {
        x_found <- x_candidate
        break
      }
    }
    if (is.null(x_found)) {
      max_pwr <- 1 - pbinom(x_search_start - 1L, n, p1)
      note <- sprintf(
        "Cannot achieve target power = %.4f with n = %d (max = %.4f)",
        target_power, n, max_pwr
      )
      warning(note)
      a_root <- 0.5; p_ach <- 0; xc <- n + 1L
    } else {
      a_root <- boundary_alpha_greater(x_found, n)

      # Verify and fine-tune: ensure find_x_greater returns x_found and calc_power is consistent
      xc_verify <- find_x_greater(n, a_root)
      if (xc_verify != x_found) {

        # For the greater test: increasing alpha narrows the CI, raising the lower bound,
        # so x_found stably excludes p0
        for (k in seq(1.001, 1.5, length.out = 20)) {
          a_try <- min(boundary_alpha_greater(x_found, n) * k, 0.999)
          if (find_x_greater(n, a_try) == x_found) {
            a_root <- a_try
            break
          }
        }
      }

      # Recompute power with the final alpha
      p_ach <- calc_power(n, a_root)
      xc <- x_found
    }
  } else if (alternative == "less") {
    x_search_start <- min(n - 1L, ceiling(n * p0) - 1L,
                          qbinom(target_power, n, p1, lower.tail = TRUE))
    x_found <- NULL
    for (x_candidate in x_search_start:0L) {
      pwr <- pbinom(x_candidate, n, p1)
      if (pwr >= target_power - 1e-12) {
        x_found <- x_candidate
        break
      }
    }
    if (is.null(x_found)) {
      max_pwr <- pbinom(x_search_start, n, p1)
      note <- sprintf(
        "Cannot achieve target power = %.4f with n = %d (max = %.4f)",
        target_power, n, max_pwr
      )
      warning(note)
      a_root <- 0.5; p_ach <- 0; xc <- -1L
    } else {
      a_root <- boundary_alpha_less(x_found, n)

      # Verify: ensure find_x_less returns x_found (not x_found - 1)
      xc_verify <- find_x_less(n, a_root)
      if (xc_verify != x_found) {

        # For the less test: increasing alpha narrows the CI, lowering the upper bound
        for (k in seq(1.001, 1.5, length.out = 20)) {
          a_try <- min(boundary_alpha_less(x_found, n) * k, 0.999)
          if (find_x_less(n, a_try) == x_found) {
            a_root <- a_try
            break
          }
        }
      }
      p_ach <- calc_power(n, a_root)
      xc <- x_found
    }
  } else {
    if (p1 > p0) {
      x_search_start <- max(floor(n * p0) + 1L, qbinom(1 - target_power, n, p1,
                                       lower.tail = TRUE))
      x_found <- NULL
      for (x_candidate in x_search_start:n) {
        pwr <- 1 - pbinom(x_candidate - 1L, n, p1)
        if (pwr >= target_power - 1e-12) {
          x_found <- x_candidate
          break
        }
      }
      if (is.null(x_found)) {
        max_pwr <- 1 - pbinom(x_search_start - 1L, n, p1)
        note <- sprintf("Cannot achieve power = %.4f with n = %d (max = %.4f)",
                        target_power, n, max_pwr)
        warning(note)
        a_root <- 0.5; p_ach <- 0; xc <- c(-1L, n + 1L)
      } else {
        a_half <- boundary_alpha_greater(x_found, n)

        # Verify one-sided alpha stability
        xc_verify <- find_x_greater(n, a_half)
        if (xc_verify != x_found) {
          for (k in seq(1.001, 1.5, length.out = 20)) {
            a_try <- min(boundary_alpha_greater(x_found, n) * k, 0.999)
            if (find_x_greater(n, a_try) == x_found) {
              a_half <- a_try
              break
            }
          }
        }
        a_root <- 2 * a_half
        if (a_root >= 1) a_root <- 0.999
        x_low <- find_x_less(n, a_half)
        p_ach <- calc_power(n, a_root)
        xc <- c(lower = x_low, upper = x_found)
      }
    } else {
      x_search_start <- min(n - 1L, ceiling(n * p0) - 1L,
                            qbinom(target_power, n, p1, lower.tail = TRUE))
      x_found <- NULL
      for (x_candidate in x_search_start:0L) {
        pwr <- pbinom(x_candidate, n, p1)
        if (pwr >= target_power - 1e-12) {
          x_found <- x_candidate
          break
        }
      }
      if (is.null(x_found)) {
        max_pwr <- pbinom(x_search_start, n, p1)
        note <- sprintf("Cannot achieve power = %.4f with n = %d (max = %.4f)",
                        target_power, n, max_pwr)
        warning(note)
        a_root <- 0.5; p_ach <- 0; xc <- c(-1L, n + 1L)
      } else {
        a_half <- boundary_alpha_less(x_found, n)

        # Verify one-sided alpha stability
        xc_verify <- find_x_less(n, a_half)
        if (xc_verify != x_found) {
          for (k in seq(1.001, 1.5, length.out = 20)) {
            a_try <- min(boundary_alpha_less(x_found, n) * k, 0.999)
            if (find_x_less(n, a_try) == x_found) {
              a_half <- a_try
              break
            }
          }
        }
        a_root <- 2 * a_half
        if (a_root >= 1) a_root <- 0.999
        x_high <- find_x_greater(n, a_half)
        p_ach <- calc_power(n, a_root)
        xc <- c(lower = x_found, upper = x_high)
      }
    }
  }

  if (mode == "check") {
    return(make_result(n_check, a_root, p_ach, xc, "check"))
  }

  make_result(n, a_root, p_ach, xc, "solve_a", note = note)
}

# S3 print method

#' @export
print.sample_size_proportion <- function(x, ...) {
  type_label <- switch(attr(x, "type"),
    solve_n = "Compute n from alpha and power",
    solve_p = "Compute power from n and alpha",
    solve_a = "Compute alpha from n and power",
    check   = "Consistency check",
    "Single-arm target value test"
  )

  typ <- attr(x, "type")
  if (typ == "solve_n") {
    n_show <- as.integer(x)
    a_show <- attr(x, "alpha")
    p_show <- attr(x, "power")
  } else if (typ == "solve_p") {
    n_show <- attr(x, "n")
    a_show <- attr(x, "alpha")
    p_show <- as.numeric(x)
  } else {
    n_show <- attr(x, "n")
    a_show <- as.numeric(x)
    p_show <- attr(x, "power")
  }
  alt    <- attr(x, "alternative")
  p0_val <- attr(x, "p0")
  xc     <- attr(x, "x_crit")

  cat("Sample size for a single-arm target value test\n")
  cat(sprintf("  Mode             : %s\n",           type_label))
  cat(sprintf("  Method           : %s\n",           attr(x, "method")))
  cat(sprintf("  H0: p %s %.4f\n",
              if (alt == "greater") "<=" else
              if (alt == "less") ">=" else "=", p0_val))
  cat(sprintf("  H1: p %s %.4f\n",
              if (alt == "greater") ">" else
              if (alt == "less") "<" else "!=", p0_val))
  cat(sprintf("  Expected p       : %.4f\n",         attr(x, "p1")))
  cat(sprintf("  Sample size (n)  : %d\n",           n_show))
  cat(sprintf("  Alpha            : %.6f\n",         a_show))
  cat(sprintf("  Power            : %.6f\n",         p_show))
  if (!is.null(xc)) {
    if (length(xc) == 1L)
      cat(sprintf("  Critical x       : %d\n", xc))
    else
      cat(sprintf("  Critical x       : [%d, %d]\n", xc[1L], xc[2L]))
  }
  note <- attr(x, "note")
  if (!is.null(note))
    cat(sprintf("  Note: %s\n", note))
  invisible(x)
}
