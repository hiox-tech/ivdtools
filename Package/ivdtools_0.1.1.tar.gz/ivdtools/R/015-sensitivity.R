#' Limit of blank, detection, and quantitation (LoB / LoD / LoQ)
#'
#' Estimates analytical sensitivity limits from a data.frame of *summarized*
#' measurements (one row per sample: a sample-name column, a mean column,
#' an SD column, and a replicate-count column). The workflow follows CLSI
#' EP17-A2:
#'
#' * **LoB** (Section 5.3.3.1, parametric option): `LoB = M_B + cp * SD_B`,
#'   pooling all blank samples, with `cp = 1.645 / sqrt(1 - 1/(4*(B - K)))`.
#' * **LoD** (Section 5.4.3): a fixed-point iteration on the fitted precision
#'   profile, `X = LoB + cp * SD_WL(X)`, solved for the smallest `X >= LoB`.
#' * **LoQ** (Appendix D1, Example 1 — functional sensitivity): the
#'   concentration `X` where the precision profile meets the target CV,
#'   i.e. `sqrt(Var(X)) / X = target_cv`.
#'
#' The precision profile is fit internally with
#' `fit_equation("sadler", ...)` (all 10 Sadler variance models; the best
#' model by AIC is used for prediction).
#'
#' Note that the LoQ reported here reflects **precision only**; bias is not
#' included. If the precision-based LoQ is below the LoD, the LoQ is reported
#' as `max(LoQ, LoD)` with a warning.
#'
#' @param data       a data.frame of summarized measurements with a sample
#'   name column, a mean column, an SD column, and an n (replicate count)
#'   column. Column names are free-form; specify them via `sample_col`,
#'   `mean_col`, `sd_col`, and `n_col`. The default column names match the
#'   output of `replicate_to_mean()`.
#' @param sample_col name of the column identifying each sample (default
#'   `"x"`).
#' @param mean_col   name of the column holding each sample's mean of
#'   replicates (default `"y_mean"`). This is used as the concentration axis
#'   of the precision profile.
#' @param sd_col     name of the column holding each sample's SD (default
#'   `"y_sd"`).
#' @param n_col      name of the column holding each sample's number of
#'   replicates (default `"y_n"`).
#' @param blank      sample name(s) in `sample_col` that are blank samples
#'   (default `NULL`). When `NULL`, only the LoQ is computed. When provided,
#'   the LoB (and then LoD) are computed from the pooled blank rows.
#' @param target_cv  target coefficient of variation for the LoQ (default
#'   `0.20`, i.e. 20%).
#' @param na.rm      remove rows with `NA` in any of the used columns?
#'   (default `TRUE`).
#' @param ...        reserved for future use.
#'
#' @return An object of class `"sensitivity"` (printed and plottable) with
#'   components:
#'   \item{lob}{LoB (parametric, pooled blanks) or `NA` when no blanks are
#'     given or the blank degrees of freedom are insufficient.}
#'   \item{lod}{LoD (fixed point on the precision profile) or `NA` when no
#'     fixed point exists in the search range.}
#'   \item{loq}{LoQ (functional sensitivity at `target_cv`), already
#'     constrained to be `>= loD` when both are finite.}
#'   \item{n_blank, B, K}{blank result count (B) and blank sample count (K).}
#'   \item{cp_lob, cp_lod}{the EP17 small-sample corrections for the LoB and
#'     LoD multipliers.}
#'   \item{target_cv}{the requested CV target.}
#'   \item{fit}{the internal `fit_equation("sadler", ...)` result, or `NULL`.}
#'   \item{model}{best Sadler model name (by AIC), or `NA`.}
#'   \item{notes}{character vector of any conditions encountered.}
#'
#'   A warning is issued whenever a limit cannot be estimated (components set
#'   to `NA`).
#'
#' @examples
#' \donttest{
#' # summarized data: two blank samples + six low levels
#' summ <- data.frame(
#'   sample = c("blank_A", "blank_B", "L1", "L2", "L3", "L4", "L5", "L6"),
#'   mean   = c(0, 0, 0.5, 1, 2, 5, 10, 20),
#'   sd     = 0.05 + 0.10 * c(0, 0, 0.5, 1, 2, 5, 10, 20),
#'   n      = c(15L, 15L, 5L, 5L, 5L, 5L, 5L, 5L)
#' )
#'
#' # 1. blank + low levels: LoB / LoD / LoQ
#' lob_lod_loq(summ, "sample", "mean", "sd", "n",
#'             blank = c("blank_A", "blank_B"))
#'
#' # 2. blanks only: LoB
#' lob_lod_loq(summ[1:2, ], "sample", "mean", "sd", "n",
#'             blank = c("blank_A", "blank_B"))
#'
#' # 3. no blanks: LoQ only
#' lob_lod_loq(summ[3:8, ], "sample", "mean", "sd", "n")
#' }
#' @export
lob_lod_loq <- function(data,
                        sample_col = "x",
                        mean_col   = "y_mean",
                        sd_col     = "y_sd",
                        n_col      = "y_n",
                        blank      = NULL,
                        target_cv  = 0.20,
                        na.rm      = TRUE,
                        ...) {
  cl <- match.call()

  # ---- validation ----
  if (!is.data.frame(data))
    stop("'data' must be a data.frame of summarized measurements.")
  cols <- c(sample_col, mean_col, sd_col, n_col)
  miss <- setdiff(cols, names(data))
  if (length(miss))
    stop("Column(s) not found in 'data': ", paste(miss, collapse = ", "),
         ". Specify the column names via sample_col/mean_col/sd_col/n_col.")
  if (length(target_cv) != 1L || !is.numeric(target_cv) ||
      !is.finite(target_cv) || target_cv <= 0)
    stop("'target_cv' must be a single positive number.")

  # ---- complete rows ----
  if (na.rm) {
    keep <- stats::complete.cases(data[, cols, drop = FALSE])
    data <- data[keep, , drop = FALSE]
  }

  notes  <- character(0)
  lob    <- NA_real_
  cp_lob <- NA_real_
  B      <- 0L
  K      <- 0L
  n_blank <- 0L

  # ---- LoB: EP17 5.3.3.1 parametric option (pooled blanks) ----
  if (!is.null(blank)) {
    bl <- data[data[[sample_col]] %in% blank, , drop = FALSE]
    if (nrow(bl) == 0L) {
      warning("No rows of 'data' match the 'blank' sample name(s); LoB = NA.")
    } else {
      K <- nrow(bl)
      B <- as.integer(sum(bl[[n_col]], na.rm = TRUE))
      n_blank <- B
      df_b <- B - K
      if (df_b < 1L) {
        warning("Blank degrees of freedom (B - K) < 1; LoB = NA.")
      } else {
        M_B <- sum(bl[[n_col]] * bl[[mean_col]], na.rm = TRUE) / B
        SD_B <- sqrt(sum((bl[[n_col]] - 1L) * bl[[sd_col]]^2, na.rm = TRUE) /
                     df_b)
        cp_lob <- 1.645 / sqrt(1 - 1 / (4 * df_b))
        lob <- M_B + cp_lob * SD_B
      }
    }
  }

  # ---- Sadler precision profile on non-blank, positive levels ----
  if (is.null(blank)) {
    fit_keep <- data[[mean_col]] > 0 & data[[sd_col]] > 0
  } else {
    fit_keep <- !(data[[sample_col]] %in% blank) &
                data[[mean_col]] > 0 & data[[sd_col]] > 0
  }
  fit_data <- data.frame(
    x   = data[[mean_col]][fit_keep],
    var = data[[sd_col]][fit_keep]^2,
    df  = data[[n_col]][fit_keep] - 1L
  )
  names(fit_data)[1L] <- mean_col

  fit <- NULL
  if (nrow(fit_data) >= 4L) {
    fit <- fit_equation("sadler", fit_data,
                        x = mean_col, y = "var", df_col = "df")
  } else if (is.null(blank)) {
    warning("Fewer than 4 non-blank levels; LoQ cannot be computed.")
  }

  # forward variance function on the best-by-AIC Sadler model
  var_at <- function(mu) {
    if (is.null(fit)) return(rep(NA_real_, length(mu)))
    suppressWarnings(pred <- stats::predict(fit$fit, newdata = as.numeric(mu)))
    as.numeric(pred$Fitted)
  }

  # smallest positive root of f(X) - target = 0 on a log-spaced, expanding grid
  .solve_root <- function(f, target, lo, hi, hard_lo = NULL) {
    for (mult in c(1, 2, 5, 10)) {
      r_lo <- lo / mult
      if (!is.null(hard_lo)) r_lo <- max(r_lo, hard_lo)
      r_hi <- hi * mult
      if (r_lo >= r_hi) next
      gx <- exp(seq(log(r_lo), log(r_hi), length.out = 400))
      gf <- f(gx) - target
      ok <- is.finite(gf)
      if (sum(ok) < 2) next
      gx <- gx[ok]
      gf <- gf[ok]
      idx <- which(diff(sign(gf)) != 0)
      roots <- numeric(0)
      for (i in idx) {
        sol <- tryCatch(
          stats::uniroot(function(u) f(u) - target,
                         c(gx[i], gx[i + 1]), maxiter = 1000)$root,
          error = function(e) NA_real_)
        if (is.finite(sol) && sol > 0) roots <- c(roots, sol)
      }
      if (length(roots) > 0) return(min(roots))
    }
    NA_real_
  }

  # ---- LoD: EP17 5.4.3 fixed point  X = LoB + cp * SD(X) ----
  lod    <- NA_real_
  cp_lod <- NA_real_
  if (is.finite(lob) && !is.null(fit)) {
    x_obs <- fit$data[[fit$x_col]]
    df_sum <- sum(fit$data$df, na.rm = TRUE)
    if (df_sum >= 1L) {
      cp_lod <- 1.645 / sqrt(1 - 1 / (4 * df_sum))
      lo0 <- max(min(x_obs) / 10, 1e-9)
      hi0 <- max(x_obs) * 2
      f_lod <- function(X) X - lob - cp_lod * sqrt(var_at(X))
      lod <- .solve_root(f_lod, 0, max(lo0, lob), hi0, hard_lo = lob)
      if (is.na(lod)) {
        notes <- c(notes,
          "LoD: no fixed-point solution (X = LoB + cp*SD(X)) in range; LoD = NA.")
        warning(notes[length(notes)])
      }
    }
  }

  # ---- LoQ: EP17 Appendix D1, functional sensitivity ----
  loq <- NA_real_
  if (!is.null(fit)) {
    x_obs <- fit$data[[fit$x_col]]
    lo0 <- max(min(x_obs) / 10, 1e-9)
    hi0 <- max(x_obs) * 2
    loq_cv <- .solve_root(function(X) sqrt(var_at(X)) / X, target_cv, lo0, hi0)
    if (is.na(loq_cv)) {
      notes <- c(notes, sprintf(
        "LoQ: CV never reaches target_cv = %g%% in the search range; LoQ = NA.",
        target_cv * 100))
      warning(notes[length(notes)])
    } else if (is.finite(lod) && loq_cv < lod) {
      notes <- c(notes, sprintf(
        "LoQ (precision) < LoD; LoQ reported as LoD = %s.",
        formatC(lod, digits = 4, format = "g")))
      warning(notes[length(notes)])
      loq <- lod
    } else {
      loq <- loq_cv
    }
  }

  model <- NA_character_
  if (!is.null(fit)) {
    model <- names(fit$fit$AIC)[which.min(fit$fit$AIC)]
  }

  structure(list(
    call      = cl,
    lob       = lob,
    lod       = lod,
    loq       = loq,
    n_blank   = n_blank,
    B         = B,
    K         = K,
    target_cv = target_cv,
    cp_lob    = cp_lob,
    cp_lod    = cp_lod,
    fit       = fit,
    model     = model,
    notes     = notes
  ), class = "sensitivity")
}

#' @export
print.sensitivity <- function(x, ...) {
  f <- function(v)
    if (is.finite(v)) formatC(v, digits = 4, format = "g") else "--"
  cat("Limit of Blank / Detection / Quantitation (EP17-A2)\n")

  if (!is.null(x$fit) && !is.na(x$model)) {
    cat(sprintf("Precision profile: Sadler; best model = %s\n", x$model))

    # best-model equation (symbolic, from the registry) and estimates
    co  <- stats::coef(x$fit)
    vfp <- x$fit$fit
    pos <- which(names(vfp$AIC) == x$model)
    if (length(pos)) {
      m_no  <- as.integer(sub("Model_", "", x$model))
      reg   <- eq_registry()
      row   <- reg[tolower(reg$id) == paste0("v0", m_no), , drop = FALSE]
      fml   <- if (nrow(row)) row$formula_str[1L] else ""
      cat(sprintf("  Equation            : sigma^2 = %s\n", fml))
      if (length(co))
        cat(sprintf("  Parameters          : %s\n",
                    paste(sprintf("%s = %s", names(co),
                                  formatC(co, digits = 5, format = "g")),
                          collapse = ", ")))
      # fit quality indicators for the best model
      aic_best <- vfp$AIC[pos]
      rss_best <- vfp$RSS[pos]
      gof_best <- vfp$GoF.pval[pos]
      cat(sprintf("  Fit                 : AIC = %s; RSS = %s; GoF p = %s\n",
                  f(aic_best), f(rss_best), f(gof_best)))
    }
  }

  cat(sprintf("  LoB  (parametric, B = %d, K = %d) : %s\n",
              x$B, x$K, f(x$lob)))
  cat(sprintf("  LoD  (fixed-point)                : %s\n", f(x$lod)))
  cat(sprintf("  LoQ  (CV = %g%%)                    : %s\n",
              x$target_cv * 100, f(x$loq)))
  cat("Note: LoQ is based on precision ONLY; bias is not included.\n")
  if (length(x$notes))
    for (n in x$notes) cat("  Note: ", n, "\n", sep = "")
  invisible(x)
}

#' @export
plot.sensitivity <- function(x, ...) {
  fit <- x$fit
  if (is.null(fit)) {
    message("No precision profile available; only LoB is reported.")
    return(invisible(x))
  }

  fd     <- fit$data
  mu     <- fd[[fit$x_col]]
  sd     <- sqrt(fd$var)
  x_grid <- seq(min(mu, na.rm = TRUE), max(mu, na.rm = TRUE), length.out = 200)
  var_at <- function(m) {
    suppressWarnings(pred <- stats::predict(fit$fit, newdata = as.numeric(m)))
    as.numeric(pred$Fitted)
  }
  sd_curve <- sqrt(var_at(x_grid))
  cv_curve <- sqrt(var_at(x_grid)) / x_grid * 100

  df_sd <- data.frame(x = mu, y = sd)
  df_cv <- data.frame(x = mu, y = sd / mu * 100)
  df_sd_line <- data.frame(x = x_grid, y = sd_curve)
  df_cv_line <- data.frame(x = x_grid, y = cv_curve)

  p1 <- ggplot2::ggplot(df_sd, ggplot2::aes(x = .data$x, y = .data$y)) +
    ggplot2::geom_point(size = 2.5, color = "grey40", alpha = 0.7, na.rm = TRUE) +
    ggplot2::geom_line(data = df_sd_line, color = "darkorange", linewidth = 1,
                       na.rm = TRUE) +
    ggplot2::labs(title = "Precision profile (SD)",
                  x = "Concentration (mean)", y = "SD") +
    ggplot2::theme_bw() +
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5))
  if (is.finite(x$lob))
    p1 <- p1 + ggplot2::geom_hline(yintercept = x$lob,
                                   linetype = "dashed", color = "steelblue")
  if (is.finite(x$lod))
    p1 <- p1 + ggplot2::geom_vline(xintercept = x$lod,
                                   linetype = "dashed", color = "darkred")

  p2 <- ggplot2::ggplot(df_cv, ggplot2::aes(x = .data$x, y = .data$y)) +
    ggplot2::geom_point(size = 2.5, color = "grey40", alpha = 0.7, na.rm = TRUE) +
    ggplot2::geom_line(data = df_cv_line, color = "darkorange", linewidth = 1,
                       na.rm = TRUE) +
    ggplot2::geom_hline(yintercept = x$target_cv * 100,
                        linetype = "dashed", color = "steelblue") +
    ggplot2::labs(title = "Precision profile (CV)",
                  x = "Concentration (mean)", y = "CV (%)") +
    ggplot2::theme_bw() +
    ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5))
  if (is.finite(x$loq))
    p2 <- p2 + ggplot2::geom_vline(xintercept = x$loq,
                                   linetype = "dashed", color = "darkred")

  # stack the two panels vertically in a 2 x 1 grid layout
  g1 <- ggplot2::ggplotGrob(p1)
  g2 <- ggplot2::ggplotGrob(p2)
  grid::grid.newpage()
  grid::pushViewport(grid::viewport(layout = grid::grid.layout(
    2, 1, heights = grid::unit(c(1, 1), "null"))))
  grid::pushViewport(grid::viewport(layout.pos.row = 1))
  grid::grid.draw(g1)
  grid::popViewport()
  grid::pushViewport(grid::viewport(layout.pos.row = 2))
  grid::grid.draw(g2)
  grid::popViewport(2)
  invisible(x)
}
