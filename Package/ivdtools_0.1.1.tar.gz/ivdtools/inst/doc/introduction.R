## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = "center",
  warning = FALSE,
  message = FALSE
)

## ----install, eval = FALSE----------------------------------------------------
# install.packages("ivdtools")
# library(ivdtools)

## ----quickstart, eval = FALSE-------------------------------------------------
# obj <- mcr(ivd_mcr_example, "sid", "test", "ref")
# summary(obj)
# plot(obj)

