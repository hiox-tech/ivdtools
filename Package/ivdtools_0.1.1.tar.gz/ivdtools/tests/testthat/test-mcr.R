test_that("MCR constructor filters only incomplete pairs and validates weights", {
  d <- data.frame(
    id = 1:5,
    x = c(1, 2, NA, 4, 5),
    y = c(1.1, 2.1, 3.1, Inf, 5.1),
    w = c(1, 2, 3, 4, 5)
  )
  m <- mcr(d, "id", "x", "y", weights = "w")
  expect_equal(m$complete_idx, c(1L, 2L, 5L))
  expect_equal(m$weights, c(1, 2, 5))
  expect_equal(m$n, 3)

  d$w[2] <- -1
  expect_error(mcr(d, "id", "x", "y", weights = "w"), "non-negative")
  expect_error(mcr(list(), "id", "x", "y"), "data frame")
  expect_error(mcr(data.frame(id = 1:2, x = 1:2), "id", "x", "y"), "column name")
})

test_that("MCR correlations agree with stats::cor.test", {
  m <- mcr(ivd_mcr_example, "sid", "test", "ref")
  for (method in c("pearson", "spearman", "kendall")) {
    observed <- quietly_value(correlation(m, method = method))$correlation
    expected <- suppressWarnings(stats::cor.test(
      ivd_mcr_example$test,
      ivd_mcr_example$ref,
      method = method
    ))
    expect_num_equal(observed$estimate, unname(expected$estimate), 1e-12)
    expect_num_equal(observed$p.value, expected$p.value, 1e-10)
  }
})

test_that("OLS and WLS regression agree with stats::lm", {
  d <- transform(ivd_mcr_example, w = seq_len(nrow(ivd_mcr_example)))
  m <- mcr(d, "sid", "test", "ref", weights = "w")

  observed_ols <- quietly_value(regression(m, method = "ols"))$regression
  expected_ols <- stats::lm(ref ~ test, data = d)
  expect_num_equal(
    c(observed_ols$intercept, observed_ols$slope),
    stats::coef(expected_ols),
    1e-12
  )
  expect_num_equal(observed_ols$residuals, stats::residuals(expected_ols), 1e-12)

  observed_wls <- quietly_value(
    regression(m, method = "wls", weights = "w")
  )$regression
  expected_wls <- stats::lm(ref ~ test, data = d, weights = w)
  expect_num_equal(
    c(observed_wls$intercept, observed_wls$slope),
    stats::coef(expected_wls),
    1e-12
  )
})

test_that("Deming regression recovers an exact linear relationship", {
  d <- data.frame(id = 1:10, candidate = 1:10, reference = 1 + 2 * (1:10))
  m <- mcr(d, "id", "candidate", "reference")
  fit <- quietly_value(regression(m, method = "deming"))$regression
  expect_equal(fit$intercept, 1, tolerance = 1e-10)
  expect_equal(fit$slope, 2, tolerance = 1e-10)
})

test_that("Bland-Altman estimates follow independent formulas", {
  m <- mcr(ivd_mcr_example, "sid", "test", "ref")
  result <- quietly_value(bland_altman(m))$bland_altman
  differences <- ivd_mcr_example$test - ivd_mcr_example$ref
  z <- stats::qnorm(0.975)

  expect_equal(result$mean_diff, mean(differences), tolerance = 1e-14)
  expect_equal(result$sd_diff, stats::sd(differences), tolerance = 1e-14)
  expect_equal(
    unname(result$loa),
    mean(differences) + c(-1, 1) * z * stats::sd(differences),
    tolerance = 1e-12
  )
})

test_that("MCR estimates are invariant to row order and transform predictably", {
  d <- ivd_mcr_example
  base <- quietly_value(regression(mcr(d, "sid", "test", "ref"), "ols"))$regression
  perm <- quietly_value(regression(
    mcr(d[c(12:1), ], "sid", "test", "ref"),
    "ols"
  ))$regression
  expect_equal(base$slope, perm$slope, tolerance = 1e-12)
  expect_equal(base$intercept, perm$intercept, tolerance = 1e-12)

  scaled <- transform(d, test = test * 10, ref = ref * 5)
  scaled_fit <- quietly_value(regression(
    mcr(scaled, "sid", "test", "ref"),
    "ols"
  ))$regression
  expect_equal(scaled_fit$slope, base$slope / 2, tolerance = 1e-12)
  expect_equal(scaled_fit$intercept, base$intercept * 5, tolerance = 1e-12)
})
