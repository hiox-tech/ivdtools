test_that("precision variance components agree with direct VCA fits", {
  d <- balanced_precision_data()
  p <- precision(d, y ~ day/run, by = "sample")
  p <- quietly_value(variance(p))

  for (sample_name in c("low", "high")) {
    sample_data <- d[d$sample == sample_name, ]
    direct <- suppressMessages(VCA::anovaVCA(y ~ day/run, Data = sample_data))
    direct_vc <- direct$aov.tab[, "VC"]
    names(direct_vc) <- rownames(direct$aov.tab)
    direct_vc <- direct_vc[names(p$results[[sample_name]]$vc)]
    expect_equal(
      p$results[[sample_name]]$vc,
      direct_vc,
      tolerance = 1e-10,
      info = sample_name
    )
  }
})

test_that("precision SD, CV, and percentages are internally coherent", {
  d <- balanced_precision_data()
  p <- quietly_value(variance(precision(d, y ~ day/run, by = "sample")))

  for (result in p$results) {
    expect_equal(result$sd_comp, sqrt(pmax(result$vc, 0)), tolerance = 1e-12)
    expect_equal(
      result$cv_comp,
      100 * result$sd_comp / result$mean,
      tolerance = 1e-12
    )
    expect_equal(
      sum(result$vc / sum(result$vc) * 100),
      100,
      tolerance = 1e-10
    )
  }
})

test_that("variance alias and confidence intervals preserve precision objects", {
  d <- balanced_precision_data()
  p <- precision(d, y ~ day/run, by = "sample")
  by_variance <- quietly_value(variance(p))
  by_alias <- quietly_value(vc(p))
  expect_equal(by_alias$results, by_variance$results)

  with_ci <- quietly_value(ci(by_variance))
  expect_s3_class(with_ci, "precision")
  expect_s3_class(with_ci$ci, "precision_ci")
  expect_true(all(as.numeric(with_ci$ci$SD$lower) >= 0))
  expect_true(all(
    as.numeric(with_ci$ci$SD$lower) <= as.numeric(with_ci$ci$SD$upper)
  ))
})

test_that("precision is invariant to row order", {
  d <- balanced_precision_data()
  p1 <- quietly_value(variance(precision(d, y ~ day/run, by = "sample")))
  p2 <- quietly_value(variance(precision(
    d[rev(seq_len(nrow(d))), ],
    y ~ day/run,
    by = "sample"
  )))
  expect_equal(p1$results$low$vc, p2$results$low$vc, tolerance = 1e-10)
  expect_equal(p1$results$high$vc, p2$results$high$vc, tolerance = 1e-10)
})

test_that("precision rejects invalid designs and incomplete prerequisites", {
  d <- balanced_precision_data()
  expect_error(precision(list(), y ~ day/run), "is.data.frame")
  expect_error(precision(d, y ~ missing/run), "not found|undefined")
  p <- precision(d, y ~ day/run, by = "sample")
  expect_output(profile(p, model.no = 1), "Run variance")
})
