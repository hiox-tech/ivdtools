test_that("percentile reference interval uses documented type-6 quantiles", {
  values <- seq_len(120)
  ri <- reference_interval(data.frame(value = values), "value", method = "percentile")
  alpha <- 0.025
  expect_equal(
    unname(ri$percentile$lower),
    unname(stats::quantile(values, alpha, type = 6))
  )
  expect_equal(
    unname(ri$percentile$upper),
    unname(stats::quantile(values, 1 - alpha, type = 6))
  )
})

test_that("parametric reference interval agrees with mean plus or minus z SD", {
  values <- c(-2, -1, 0, 1, 2, -1.5, 1.5, -0.5, 0.5)
  ri <- suppressWarnings(reference_interval(
    data.frame(value = values), "value", method = "parametric"
  ))
  z <- stats::qnorm(0.975)
  expected <- mean(values) + c(-1, 1) * z * stats::sd(values)
  expect_num_equal(c(ri$parametric$lower, ri$parametric$upper), expected, 1e-12)
})

test_that("reference intervals report missing and duplicate IDs", {
  d <- data.frame(id = c(1, 1, 2, 2), value = c(1, NA, 3, 4))
  ri <- suppressWarnings(reference_interval(d, "value", id = "id"))
  expect_equal(ri$n_miss, 1)
  expect_equal(ri$n_complete, 3)
  expect_equal(ri$n_duplicates, 2)
  expect_equal(ri$dup_rows, c(3L, 4L))
})

test_that("outlier procedures identify a clear extreme observation", {
  d <- data.frame(value = c(rep(10, 8), 100))
  for (method in c("grubbs", "esd", "dixon", "iqr")) {
    result <- outliers_test(d, "value", method = method)
    expect_s3_class(result, "outliers_test")
    expect_true(9L %in% result$indices, info = method)
  }
})

test_that("normality statistics agree with their source packages", {
  set.seed(20260726)
  d <- data.frame(value = stats::rnorm(50))

  shapiro <- normal_test(d, "value", method = "shapiro")
  direct_shapiro <- stats::shapiro.test(d$value)
  expect_equal(shapiro$statistic, unname(direct_shapiro$statistic), tolerance = 1e-12)
  expect_equal(shapiro$p_value, direct_shapiro$p.value, tolerance = 1e-12)

  ad <- normal_test(d, "value", method = "ad")
  direct_ad <- nortest::ad.test(d$value)
  expect_equal(ad$statistic, unname(direct_ad$statistic), tolerance = 1e-12)
  expect_equal(ad$p_value, direct_ad$p.value, tolerance = 1e-12)
})

test_that("reference and distribution tools reject degenerate inputs", {
  expect_error(reference_interval(data.frame(x = letters[1:4]), "x"), "numeric")
  expect_equal(
    outliers_test(data.frame(x = 1:2), "x", method = "grubbs")$n_outliers,
    0L
  )
  constant <- normal_test(data.frame(x = rep(1, 5)), "x")
  expect_true(is.na(constant$test_method))
  expect_true(is.na(constant$statistic))
  expect_true(is.na(constant$p_value))
})
