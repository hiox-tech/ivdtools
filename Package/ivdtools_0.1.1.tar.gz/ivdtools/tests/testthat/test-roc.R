test_that("ROC AUC agrees with the independent rank definition", {
  marker <- c(0.1, 0.4, 0.4, 0.8, 0.9, 1.2, 1.2, 1.5)
  truth <- c(0, 0, 1, 0, 1, 1, 0, 1)
  d <- data.frame(marker = marker, truth = truth)
  r0 <- roc(d, "marker", "truth")
  r <- quietly_value(auc(r0))
  oriented_marker <- if (r0$col_direction$marker == "geq") marker else -marker

  expect_equal(
    r$auc_list$marker$auc,
    manual_auc(oriented_marker, truth),
    tolerance = 1e-12
  )
})

test_that("ROC handles perfect, reversed, and tied markers", {
  truth <- rep(c(0, 1), each = 5)
  perfect <- data.frame(marker = c(1:5, 11:15), truth = truth)
  reverse <- data.frame(marker = -perfect$marker, truth = truth)
  tied <- data.frame(marker = rep(1, 10), truth = truth)

  a1 <- quietly_value(auc(roc(perfect, "marker", "truth")))$auc_list$marker$auc
  a2 <- quietly_value(auc(roc(reverse, "marker", "truth")))$auc_list$marker$auc
  a3 <- quietly_value(auc(roc(tied, "marker", "truth")))$auc_list$marker$auc

  expect_equal(a1, 1)
  expect_equal(a2, 1)
  expect_equal(a3, 0.5)
})

test_that("ROC cutoff rows contain independently computed confusion metrics", {
  d <- data.frame(marker = 1:8, truth = c(0, 0, 1, 0, 1, 1, 0, 1))
  r <- quietly_value(auc(roc(d, "marker", "truth")))
  r <- quietly_value(cutoff(r))
  row <- r$cutoff_table[r$cutoff_table$column == "marker" &
                          r$cutoff_table$cutoff == 5, ]
  pred <- as.integer(d$marker >= 5)

  expect_equal(row$tp, sum(pred == 1 & d$truth == 1))
  expect_equal(row$fp, sum(pred == 1 & d$truth == 0))
  expect_equal(row$tn, sum(pred == 0 & d$truth == 0))
  expect_equal(row$fn, sum(pred == 0 & d$truth == 1))
})

test_that("multivariate ROC logistic fit and prediction agree with glm", {
  d <- data.frame(
    x1 = seq(-2, 2, length.out = 20),
    x2 = rep(c(-1, 1), 10),
    truth = rep(c(0, 0, 1, 0, 1), 4)
  )
  r <- quietly_value(auc(roc(d, c("x1", "x2"), "truth")))
  r <- quietly_value(mlr(r, name = "model"))
  expected <- stats::glm(truth ~ x1 + x2, data = d, family = stats::binomial())

  expect_equal(
    stats::coef(r$mlr_results$model$fit),
    stats::coef(expected),
    tolerance = 1e-10
  )

  newdata <- data.frame(x1 = c(-0.5, 0.5), x2 = c(1, -1))
  observed <- predict(r, newdata = newdata, mlr = "model")
  expected_prob <- stats::predict(expected, newdata, type = "response")
  expect_num_equal(observed$pred_prob, expected_prob, 1e-10)
})

test_that("ROC validates reference and analysis ordering", {
  expect_error(roc(data.frame(x = 1:4, ref = 1:4), "x", "ref"), "quantitative")
  expect_error(roc(data.frame(x = letters[1:4], ref = c(0, 1, 0, 1)), "x", "ref"), "numeric")
  r <- roc(data.frame(x = 1:4, ref = c(0, 1, 0, 1)), "x", "ref")
  expect_error(cutoff(r), "auc")
  expect_error(mlr(r), "auc")
})
