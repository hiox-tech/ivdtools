test_that("Bland-Altman power matches its noncentral-t equation", {
  n <- 60
  mu <- 0.2
  sigma <- 1
  delta <- 2.5
  observed <- sample_size_bland_altman(n = n, mu = mu, sd = sigma, delta = delta)
  zg <- stats::qnorm(0.975)
  se <- sigma * sqrt(1 / n + zg^2 / (2 * (n - 1)))
  tc <- stats::qt(0.975, n - 1)
  expected <- stats::pt(tc, n - 1, ncp = (delta - mu - zg * sigma) / se,
                       lower.tail = FALSE) +
    stats::pt(-tc, n - 1, ncp = (delta + mu - zg * sigma) / se)
  expect_equal(as.numeric(observed), expected, tolerance = 1e-12)
})

test_that("sample-size solvers return the first size attaining the target", {
  n <- as.integer(sample_size_bland_altman(
    power = 0.8, mu = 0.2, sd = 1, delta = 2.5
  ))
  expect_gte(unclass(sample_size_bland_altman(
    n = n, mu = 0.2, sd = 1, delta = 2.5
  )), 0.8)
  expect_lt(unclass(sample_size_bland_altman(
    n = n - 1L, mu = 0.2, sd = 1, delta = 2.5
  )), 0.8)
})

test_that("Wald CI sample size and half-width use closed-form equations", {
  p <- 0.3
  d <- 0.05
  z <- stats::qnorm(0.975)
  n <- sample_size_proportion_ci(p = p, d = d, method = "wald")
  expect_equal(as.integer(n), ceiling(z^2 * p * (1 - p) / d^2))
  hw <- sample_size_proportion_ci(p = p, n = as.integer(n), method = "wald")
  expect_equal(as.numeric(hw), z * sqrt(p * (1 - p) / as.integer(n)),
               tolerance = 1e-12)
})

test_that("proportion test size has attained power and monotone behavior", {
  a <- sample_size_proportion(p0 = 0.2, p1 = 0.35, power = 0.8, alpha = 0.05)
  expect_gte(attr(a, "power"), 0.8)
  harder <- sample_size_proportion(p0 = 0.2, p1 = 0.3, power = 0.8, alpha = 0.05)
  expect_gt(as.integer(harder), as.integer(a))
})

test_that("sample-size functions enforce mutually exclusive unknowns", {
  expect_error(sample_size_bland_altman(mu = 0, sd = 1, delta = 2), "Exactly")
  expect_error(sample_size_proportion_ci(p = 0.3, n = 10, d = 0.1), "Exactly")
  expect_error(sample_size_proportion(
    p0 = 0.4, p1 = 0.3, power = 0.8, alpha = 0.05,
    alternative = "greater"
  ), "must be >")
})
