test_that("full pipeline: LoB / LoD / LoQ match EP17-A2 and analytic values", {
  summ <- data.frame(
    sample = c("blank_A", "blank_B", "L1", "L2", "L3", "L4", "L5", "L6"),
    mean   = c(0, 0, 0.5, 1, 2, 5, 10, 20),
    sd     = 0.05 + 0.10 * c(0, 0, 0.5, 1, 2, 5, 10, 20),
    n      = c(15L, 15L, 5L, 5L, 5L, 5L, 5L, 5L)
  )
  res <- quietly_value(
    lob_lod_loq(summ, "sample", "mean", "sd", "n",
                blank = c("blank_A", "blank_B"))
  )

  expect_s3_class(res, "sensitivity")

  # LoB (EP17 5.3.3.1): pooled blanks with the small-sample correction
  B <- 30L; K <- 2L; df_b <- B - K
  cp_lob <- 1.645 / sqrt(1 - 1 / (4 * df_b))
  expect_num_equal(res$lob, 0 + cp_lob * 0.05, tolerance = 1e-6)
  expect_num_equal(res$B, 30L)
  expect_num_equal(res$K, 2L)
  expect_num_equal(res$cp_lob, cp_lob)

  # LoD (EP17 5.4.3 fixed point): X = LoB + cp * SD(X), SD(X) = 0.05 + 0.10 X
  df_sum <- 6 * (5L - 1L)
  cp_lod <- 1.645 / sqrt(1 - 1 / (4 * df_sum))
  lod_ana <- (res$lob + cp_lod * 0.05) / (1 - cp_lod * 0.10)
  expect_num_equal(res$lod, lod_ana, tolerance = 1e-6)
  expect_num_equal(res$cp_lod, cp_lod)

  # LoQ (EP17 D1 functional sensitivity): CV(X) = (0.05 + 0.10 X)/X = 0.20
  # (solver returns the CV crossing to ~1e-5; compare with a loose tolerance)
  expect_num_equal(res$loq, 0.5, tolerance = 1e-3)

  expect_equal(res$model, "Model_4")
})

test_that("custom column names give identical results", {
  summ <- data.frame(
    sample = c("blank_A", "blank_B", "L1", "L2", "L3", "L4", "L5", "L6"),
    mean   = c(0, 0, 0.5, 1, 2, 5, 10, 20),
    sd     = 0.05 + 0.10 * c(0, 0, 0.5, 1, 2, 5, 10, 20),
    n      = c(15L, 15L, 5L, 5L, 5L, 5L, 5L, 5L)
  )
  renamed <- summ
  names(renamed) <- c("conc", "avg", "s", "rep")

  a <- quietly_value(lob_lod_loq(summ, "sample", "mean", "sd", "n",
                                 blank = c("blank_A", "blank_B")))
  b <- quietly_value(lob_lod_loq(renamed, "conc", "avg", "s", "rep",
                                 blank = c("blank_A", "blank_B")))
  expect_num_equal(b$lob, a$lob)
  expect_num_equal(b$lod, a$lod)
  expect_num_equal(b$loq, a$loq)
})

test_that("blank matches multiple pooled blank samples by name", {
  summ <- data.frame(
    sample = c("blank_A", "blank_B", "L1", "L2", "L3", "L4", "L5", "L6"),
    mean   = c(0, 0, 0.5, 1, 2, 5, 10, 20),
    sd     = 0.05 + 0.10 * c(0, 0, 0.5, 1, 2, 5, 10, 20),
    n      = c(15L, 15L, 5L, 5L, 5L, 5L, 5L, 5L)
  )
  res <- quietly_value(
    lob_lod_loq(summ, "sample", "mean", "sd", "n",
                blank = c("blank_A", "blank_B"))
  )
  # pooled SD across the two identical blank samples is their common SD
  expect_num_equal(res$lob,
                   0 + (1.645 / sqrt(1 - 1 / (4 * (30 - 2)))) * 0.05,
                   tolerance = 1e-6)
  expect_equal(res$K, 2L)

  # blank samples are excluded from the precision-profile fit
  expect_false(is.null(res$fit))
  fd <- res$fit$data
  expect_equal(nrow(fd), 6L)                       # only the 6 low levels
  expect_true(all(fd[[res$fit$x_col]] > 0))        # no zero-concentration rows
  # the fit x values are exactly the non-blank mean concentrations
  nb_mean <- summ$mean[!(summ$sample %in% c("blank_A", "blank_B"))]
  expect_setequal(fd[[res$fit$x_col]], nb_mean)
})

test_that("blank-only data returns LoB with LoD/LoQ = NA", {
  summ <- data.frame(
    sample = c("blank_A", "blank_B"),
    mean   = c(0, 0),
    sd     = c(0.05, 0.05),
    n      = c(15L, 15L)
  )
  res <- quietly_value(
    lob_lod_loq(summ, "sample", "mean", "sd", "n",
                blank = c("blank_A", "blank_B"))
  )
  expect_true(is.finite(res$lob))
  expect_true(is.na(res$lod))
  expect_true(is.na(res$loq))
  expect_null(res$fit)
})

test_that("no-blank data returns only LoQ", {
  summ <- data.frame(
    sample = paste0("L", 1:6),
    mean   = c(0.5, 1, 2, 5, 10, 20),
    sd     = 0.05 + 0.10 * c(0.5, 1, 2, 5, 10, 20),
    n      = rep(5L, 6)
  )
  res <- quietly_value(lob_lod_loq(summ, "sample", "mean", "sd", "n"))
  expect_true(is.na(res$lob))
  expect_true(is.na(res$lod))
  expect_num_equal(res$loq, 0.5, tolerance = 1e-3)
})

test_that("LoQ < LoD is reported as LoD with a warning", {
  d <- data.frame(
    sample = c("blank", paste0("L", 1:6)),
    mean   = c(0, 0.5, 1, 2, 5, 10, 20),
    sd     = c(5, sqrt(0.01 + 0.02 * c(0.5, 1, 2, 5, 10, 20)^2)),
    n      = c(30L, rep(5L, 6))
  )
  expect_warning(
    res <- lob_lod_loq(d, "sample", "mean", "sd", "n", blank = "blank"),
    "LoQ"
  )
  expect_true(is.finite(res$lod))
  expect_num_equal(res$loq, res$lod)
  expect_true(any(grepl("LoD", res$notes)))
})

test_that("LoD with no fixed point is NA with a warning", {
  d <- data.frame(
    sample = c("blank", paste0("L", 1:6)),
    mean   = c(0, 0.5, 1, 2, 5, 10, 20),
    sd     = c(0.05, 1.0 + 2.0 * c(0.5, 1, 2, 5, 10, 20)),
    n      = c(30L, rep(5L, 6))
  )
  # this dataset has no LoD fixed point AND no LoQ crossing, so the function
  # emits both warnings; assert via notes instead of warning capture
  res <- suppressWarnings(
    lob_lod_loq(d, "sample", "mean", "sd", "n", blank = "blank")
  )
  expect_true(is.na(res$lod))
  expect_true(any(grepl("LoD: no fixed-point", res$notes)))
})

test_that("LoQ below the CV floor is NA with a warning", {
  d <- data.frame(
    sample = c("blank", paste0("L", 1:6)),
    mean   = c(0, 0.5, 1, 2, 5, 10, 20),
    sd     = 0.05 + 0.10 * c(0, 0.5, 1, 2, 5, 10, 20),
    n      = c(30L, rep(5L, 6))
  )
  expect_warning(
    res <- lob_lod_loq(d, "sample", "mean", "sd", "n", target_cv = 0.02),
    "LoQ"
  )
  expect_true(is.na(res$loq))
})

test_that("insufficient blank degrees of freedom gives LoB = NA", {
  d <- data.frame(
    sample = c("blank", paste0("L", 1:6)),
    mean   = c(0, 0.5, 1, 2, 5, 10, 20),
    sd     = 0.05 + 0.10 * c(0, 0.5, 1, 2, 5, 10, 20),
    n      = c(1L, rep(5L, 6))
  )
  expect_warning(
    res <- lob_lod_loq(d, "sample", "mean", "sd", "n", blank = "blank"),
    "degrees of freedom"
  )
  expect_true(is.na(res$lob))
})

test_that("blank NA values are handled via na.rm", {
  d <- data.frame(
    sample = c("blank", paste0("L", 1:6)),
    mean   = c(0, 0.5, 1, 2, 5, 10, 20),
    sd     = 0.05 + 0.10 * c(0, 0.5, 1, 2, 5, 10, 20),
    n      = c(30L, rep(5L, 6))
  )
  d2 <- rbind(d, data.frame(
    sample = "blank",
    mean   = NA_real_,
    sd     = NA_real_,
    n      = NA_integer_
  ))
  res <- quietly_value(
    lob_lod_loq(d2, "sample", "mean", "sd", "n", blank = "blank")
  )
  # the all-NA duplicate row is dropped by na.rm
  expect_equal(res$B, 30L)
  expect_true(is.finite(res$lob))
})

test_that("constant-variance (V01-type) data completes without inverse errors", {
  d <- data.frame(
    sample = c("blank", paste0("L", 1:6)),
    mean   = c(0, 0.5, 1, 2, 5, 10, 20),
    sd     = c(0.05, rep(0.1, 6)),
    n      = c(30L, rep(5L, 6))
  )
  res <- quietly_value(
    lob_lod_loq(d, "sample", "mean", "sd", "n", blank = "blank")
  )
  # constant SD -> LoD = LoB + cp * SD (fixed point reduces to closed form)
  expect_true(is.finite(res$lod))
  expect_num_equal(res$lod, res$lob + res$cp_lod * 0.1, tolerance = 1e-6)
  expect_true(is.finite(res$loq))
})

test_that("print.sensitivity renders limits and precision-only note", {
  summ <- data.frame(
    sample = c("blank_A", "blank_B", "L1", "L2", "L3", "L4", "L5", "L6"),
    mean   = c(0, 0, 0.5, 1, 2, 5, 10, 20),
    sd     = 0.05 + 0.10 * c(0, 0, 0.5, 1, 2, 5, 10, 20),
    n      = c(15L, 15L, 5L, 5L, 5L, 5L, 5L, 5L)
  )
  res <- quietly_value(
    lob_lod_loq(summ, "sample", "mean", "sd", "n",
                blank = c("blank_A", "blank_B"))
  )
  expect_output(print(res), "LoB")
  expect_output(print(res), "precision")
  expect_output(print(res), "bias")
  expect_output(print(res), "Equation")
  expect_output(print(res), "Parameters")
  expect_output(print(res), "Fit")
  expect_output(print(res), "AIC")
  expect_output(print(res), res$model)
})

test_that("plot.sensitivity draws the two-panel precision profile", {
  summ <- data.frame(
    sample = c("blank_A", "blank_B", "L1", "L2", "L3", "L4", "L5", "L6"),
    mean   = c(0, 0, 0.5, 1, 2, 5, 10, 20),
    sd     = 0.05 + 0.10 * c(0, 0, 0.5, 1, 2, 5, 10, 20),
    n      = c(15L, 15L, 5L, 5L, 5L, 5L, 5L, 5L)
  )
  res <- quietly_value(
    lob_lod_loq(summ, "sample", "mean", "sd", "n",
                blank = c("blank_A", "blank_B"))
  )
  pdf(NULL)
  expect_invisible(plot(res))
  dev.off()

  # blank-only: message, no drawing
  r2 <- quietly_value(
    lob_lod_loq(summ[1:2, ], "sample", "mean", "sd", "n",
                blank = c("blank_A", "blank_B"))
  )
  expect_message(plot(r2), "only LoB")
})

test_that("argument validation errors are raised", {
  summ <- data.frame(
    sample = c("blank", paste0("L", 1:6)),
    mean   = c(0, 0.5, 1, 2, 5, 10, 20),
    sd     = 0.05 + 0.10 * c(0, 0.5, 1, 2, 5, 10, 20),
    n      = c(30L, rep(5L, 6))
  )
  expect_error(lob_lod_loq(summ, "sample", "mean", "sd", "n",
                           target_cv = 0), "'target_cv'")
  expect_error(lob_lod_loq(summ, "sample", "mean", "sd", "n",
                           target_cv = -0.1), "'target_cv'")
  expect_error(lob_lod_loq(summ, "missing_col", "mean", "sd", "n"),
               "not found")
  expect_error(lob_lod_loq(matrix(1:6, 2), "a", "b", "c", "d"),
               "data.frame")
})
