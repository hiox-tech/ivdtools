# ivdtools 0.1.3

* Added explicit precision-profile model selection to `lob_lod_loq()` and
  made its analytical-sensitivity tests robust to platform-dependent model
  selection for exactly fitted nested Sadler models.

# ivdtools 0.1.2

* Initial release.
